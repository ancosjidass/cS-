"""Free-tier LLM gateway with automatic fail-over.

Every provider here has a FREE plan whose quota is per day. The gateway walks an ordered chain
(`AI_CHAIN`); when one entry answers 429 (quota gone) it is parked until its reset time and the next entry
is used. When every entry is parked the caller gets `AIUnavailable(reset_at)` - the owner is told
"come back after HH:MM" and everything works again by itself the next day.

    AI_CHAIN=groq:openai/gpt-oss-120b,groq:openai/gpt-oss-20b,nvidia:openai/gpt-oss-20b,openrouter:openrouter/free
    GROQ_API_KEY=...  NVIDIA_API_KEY=...  OPENROUTER_API_KEY=...        (entries without a key are skipped)
    AI_CUSTOM_BASE / AI_CUSTOM_KEY / AI_CUSTOM_MODEL                    any other OpenAI-compatible endpoint (`custom:`)

Limits are per MODEL on Groq/NVIDIA, so the same provider with two models doubles the free quota.
"""
from __future__ import annotations

import logging
import os
import re
import time
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from typing import Any

import aiohttp

log = logging.getLogger(__name__)

BASES = {
    "groq": ("https://api.groq.com/openai/v1", "GROQ_API_KEY"),
    "nvidia": ("https://integrate.api.nvidia.com/v1", "NVIDIA_API_KEY"),
    "openrouter": ("https://openrouter.ai/api/v1", "OPENROUTER_API_KEY"),
}
DEFAULT_CHAIN = ("groq:openai/gpt-oss-120b,groq:openai/gpt-oss-20b,nvidia:openai/gpt-oss-20b,openrouter:openrouter/free")
TIMEOUT = aiohttp.ClientTimeout(total=50)
_DAILY = re.compile(r"per day|daily|\bRPD\b|\bTPD\b|requests per day|tokens per day|quota", re.I)
_RETRY_IN = re.compile(r"try again in\s+(?:(\d+)h)?\s*(?:(\d+)m)?\s*(?:([\d.]+)s)?", re.I)
_THINK = re.compile(r"<think>.*?</think>", re.S | re.I)


class AIError(Exception):
    pass


class AINotConfigured(AIError):
    pass


class AIUnavailable(AIError):
    """Every configured free quota is used up for now. `reset_at` = epoch seconds of the earliest recovery."""

    def __init__(self, reset_at: float, detail: str = ""):
        super().__init__(detail or "all AI quotas exhausted")
        self.reset_at = reset_at


@dataclass
class Entry:
    provider: str
    model: str
    base: str
    key: str

    @property
    def name(self) -> str:
        return f"{self.provider}:{self.model}"


# entry name -> (parked until epoch, reason)
PARKED: dict[str, tuple[float, str]] = {}
STATS: dict[str, int] = {}


def next_utc_midnight(now: float | None = None) -> float:
    dt = datetime.fromtimestamp(now or time.time(), timezone.utc)
    nxt = (dt + timedelta(days=1)).replace(hour=0, minute=1, second=0, microsecond=0)
    return nxt.timestamp()


def load_chain(env: dict[str, str] | None = None) -> list[Entry]:
    env = env if env is not None else os.environ
    out: list[Entry] = []
    for raw in (env.get("AI_CHAIN") or DEFAULT_CHAIN).split(","):
        raw = raw.strip()
        if ":" not in raw:
            continue
        prov, model = raw.split(":", 1)
        prov = prov.strip().lower()
        if prov == "custom":
            base, key = (env.get("AI_CUSTOM_BASE") or "").rstrip("/"), env.get("AI_CUSTOM_KEY") or ""
            model = model.strip() or env.get("AI_CUSTOM_MODEL") or ""
        elif prov in BASES:
            base, key = BASES[prov][0], env.get(BASES[prov][1]) or ""
        else:
            continue
        if base and key.strip() and model.strip():
            out.append(Entry(prov, model.strip(), base, key.strip()))
    return out


def park(entry: str, until: float, reason: str) -> None:
    PARKED[entry] = (until, reason)
    log.info("AI %s parked until %s (%s)", entry, datetime.fromtimestamp(until).isoformat(timespec="minutes"), reason)


def _retry_seconds(headers: Any, body: str) -> float | None:
    val = headers.get("retry-after") if headers else None
    if val:
        try:
            return float(val)
        except ValueError:
            pass
    m = _RETRY_IN.search(body or "")
    if m and any(m.groups()):
        h, mi, s = (float(x) if x else 0.0 for x in m.groups())
        return h * 3600 + mi * 60 + s
    return None


def classify(status: int, headers: Any, body: str, now: float | None = None) -> tuple[float, str]:
    """(parked-until, reason) for a failed response."""
    now = now or time.time()
    if status == 429:
        wait = _retry_seconds(headers, body)
        if wait is not None and wait > 0:
            return now + min(wait + 5, 86400 + 3600), "rate limit"
        return (next_utc_midnight(now), "daily quota") if _DAILY.search(body or "") else (now + 90, "rate limit")
    if status in (401, 403):
        return now + 6 * 3600, "key rejected / region blocked"
    if status in (404, 400) and re.search(r"model", body or "", re.I):
        return now + 3600, "model unavailable"
    return now + 30, f"http {status}"


def clean(text: str) -> str:
    return _THINK.sub("", text or "").strip()


async def chat(messages: list[dict[str, str]], *, max_tokens: int = 700, temperature: float = 0.5,
               chain: list[Entry] | None = None, session: aiohttp.ClientSession | None = None) -> tuple[str, str]:
    """Returns (answer, entry name). Raises AINotConfigured / AIUnavailable."""
    entries = chain if chain is not None else load_chain()
    if not entries:
        raise AINotConfigured("no AI key configured")
    now = time.time()
    own = session is None
    sess = session or aiohttp.ClientSession(timeout=TIMEOUT)
    earliest = None
    try:
        for e in entries:
            until = PARKED.get(e.name, (0, ""))[0]
            if until > now:
                earliest = until if earliest is None else min(earliest, until)
                continue
            payload = {"model": e.model, "messages": messages, "max_tokens": max_tokens, "temperature": temperature}
            try:
                async with sess.post(f"{e.base}/chat/completions", json=payload,
                                     headers={"Authorization": f"Bearer {e.key}", "Content-Type": "application/json"}) as r:
                    body = await r.text()
                    if r.status == 200:
                        import json as _json
                        data = _json.loads(body)
                        text = clean(((data.get("choices") or [{}])[0].get("message") or {}).get("content") or "")
                        if not text:
                            park(e.name, now + 30, "empty answer")
                            continue
                        STATS[e.name] = STATS.get(e.name, 0) + 1
                        return text, e.name
                    until, why = classify(r.status, r.headers, body)
                    park(e.name, until, why)
                    earliest = until if earliest is None else min(earliest, until)
            except (aiohttp.ClientError, TimeoutError, ValueError) as exc:
                park(e.name, now + 30, exc.__class__.__name__)
                earliest = (now + 30) if earliest is None else min(earliest, now + 30)
    finally:
        if own:
            await sess.close()
    raise AIUnavailable(earliest or next_utc_midnight())


async def transcribe(data: bytes, filename: str = "voice.ogg", *, language: str | None = None) -> str:
    """Speech -> text through Groq's free Whisper endpoint (needs GROQ_API_KEY)."""
    key = os.getenv("GROQ_API_KEY", "").strip()
    if not key:
        raise AINotConfigured("GROQ_API_KEY is needed for speech-to-text")
    name = "groq-stt"
    until = PARKED.get(name, (0, ""))[0]
    if until > time.time():
        raise AIUnavailable(until)
    form = aiohttp.FormData()
    form.add_field("file", data, filename=filename, content_type="application/octet-stream")
    form.add_field("model", os.getenv("AI_STT_MODEL", "whisper-large-v3-turbo"))
    form.add_field("response_format", "json")
    if language:
        form.add_field("language", language)
    async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=120)) as s:
        try:
            async with s.post(BASES["groq"][0] + "/audio/transcriptions", data=form, headers={"Authorization": f"Bearer {key}"}) as r:
                body = await r.text()
                if r.status == 200:
                    import json as _json
                    return (_json.loads(body).get("text") or "").strip()
                until, why = classify(r.status, r.headers, body)
                park(name, until, why)
                raise AIUnavailable(until, why)
        except (aiohttp.ClientError, TimeoutError) as exc:
            raise AIError(f"speech service unreachable: {exc.__class__.__name__}") from exc


def status_lines(now: float | None = None, tz_offset_hours: float = 3.5) -> list[str]:
    now = now or time.time()
    chain = load_chain()
    if not chain:
        return ["❌ هیچ کلیدی تنظیم نشده (GROQ_API_KEY / NVIDIA_API_KEY / OPENROUTER_API_KEY در .env)."]
    lines = []
    for e in chain:
        until, why = PARKED.get(e.name, (0, ""))
        if until > now:
            when = datetime.fromtimestamp(until, timezone(timedelta(hours=tz_offset_hours))).strftime("%H:%M")
            lines.append(f"⏸ {e.name} — {why}، تا {when}")
        else:
            lines.append(f"✅ {e.name} — آماده ({STATS.get(e.name, 0)} پاسخ از شروع)")
    return lines
