from __future__ import annotations

import logging
import os
import re
from datetime import datetime
from pathlib import Path
from typing import Any
from zoneinfo import ZoneInfo

from telethon import Button, TelegramClient, events

from core.identity import my_id
from providers.crypto import MarketProvider
from providers.fx import FXProvider

log = logging.getLogger(__name__)

BOT_TOKEN = os.getenv("BOT_TOKEN", "").strip()
UI_ENABLED = os.getenv("UI_ENABLED", "true").lower() not in {"0", "false", "no"}
OWNER_ID = int(os.getenv("HAPOYI_OWNER_ID", "0") or 0)
BOT_SESSION = os.getenv(
    "HAPOYI_BOT_SESSION",
    str(Path(__file__).resolve().parents[1] / "data" / "hapoyi_ui_bot"),
)
PREFIX = os.getenv("COMMAND_PREFIX", ".") or "."
TIMEZONE = os.getenv("TIMEZONE", "Asia/Tehran") or "Asia/Tehran"

_bot: TelegramClient | None = None
_fleet: Any = None

SECTIONS: dict[str, tuple[str, str, tuple[str, ...]]] = {
    "relations": (
        "🤝 دوست / دشمن",
        "پاسخ‌های تصادفی برای کاربران مشخص با کنترل cooldown",
        ("friend add", "friend list", "friend reply", "enemy add", "enemy list", "enemy reply", "relation stats", "relation replies", "relation clear", "relation reset"),
    ),
    "echo": (
        "🔁 Echo و روزمره",
        "اکو برای کاربران مجاز، todo، تبدیل ارز، کپی، بکاپ",
        ("echo add", "echo list", "echo clear", "repeat on", "repeat off", "repeat list", "repeat clear", "todo", "conv", "ping", "copy", "backup", "msginfo"),
    ),
    "power": (
        "⚡ ابزارهای قدرتی",
        "تکرار پیام، تگ، زمان‌بندی، قفل گروه، نظرسنجی و ...",
        ("every 10m 5 متن", "every 10m - متن", "tag", "later", "top", "export", "slowmode", "lock", "unlock", "delall", "poll", "qr", "pass", "link"),
    ),
    "admin": (
        "🛡 مدیریت گروه",
        "ابزارهای مدیریت و کنترل اعضای گروه",
        ("ban", "unban", "kick", "mute", "unmute", "warn", "warnings", "unwarn", "del", "purge", "delmes", "pin", "unpin", "admins"),
    ),
    "security": (
        "🔐 امنیت و نگهبان",
        "محافظت، فیلتر، AutoDelete و AutoBan",
        ("autoban", "whitelist", "autodelete", "filter", "flood", "safety", "floodguard"),
    ),
    "chat": (
        "👥 امکانات چت",
        "خوش‌آمد، خروج، لینک‌گارد و کنترل نرخ پیام",
        ("welcome", "leave", "linkguard", "linkguard threshold", "rate"),
    ),
    "account": (
        "🔐 اکانت و لایسنس",
        "چندحسابی با لایسنس، محافظ اکانت (protect) و ابزار وضعیت",
        ("whoami", "deactivate", "report on", "report off", "report status", "protect on", "protect off", "protect status", "lic new", "lic list"),
    ),
    "personal": (
        "🧠 شخصی",
        "AFK، یادداشت، یادآوری، پروفایل و اطلاعات",
        ("afk", "back", "note", "remind", "clock", "profileclock", "clone", "unclone", "bio", "stats", "userinfo", "chatinfo", "time"),
    ),
    "crypto": (
        "💰 بازار و کریپتو",
        "قیمت‌ها، هشدارها و پرتفوی",
        ("price", "pricesrc", "market", "alert", "alerts", "alertdel", "hold", "portfolio"),
    ),
    "tools": (
        "🧰 ابزارها",
        "محاسبه، پیام، جست‌وجو و واکنش",
        ("calc", "msginfo", "id", "save", "search", "readall", "react", "rawchat"),
    ),
    "media": (
        "🎞️ مدیا",
        "دانلود به Saved Messages، اسکرین‌شات‌استیکر، تغییر اندازه و واترمارک",
        ("download / دانلود", "ss / اسکرین", "sticker", "gif", "rename", "resize", "watermark"),
    ),
    "message": (
        "🧹 ابزار پیام",
        "حذف زمان‌دار، Self-destruct و پاک‌سازی",
        ("delafter", "selfdestruct", "cleanme"),
    ),
    "games": (
        "🎲 بازی‌ها",
        "Casino و بازی‌های تاسی",
        ("casino", "slots", "dice", "dart", "bowling", "basket", "football", "game list", "game cancel", "coin", "rps (دو نفره)", "rps 5", "rps rock", "xo (دو نفره، دکمهٔ Join)", "roulette", "8ball", "blackjack", "roll", "choose", "game score", "leaderboard"),
    ),
    "plus": (
        "✨ Hāpoyi Plus",
        "۱۵ قابلیت کاربردی: تایمر، تبدیل واحد، هزینه، عادت، تولد، DND و ...",
        ("timer", "fake", "stop fake all", "unit", "greet", "dnd", "bday", "spend", "habit", "snip", "fancy", "hash", "b64", "wc", "pomo", "quote", "unread", "plus"),
    ),
    "automation": (
        "⏰ اتوماسیون",
        "AutoReply، AutoReact، Watch و Notify",
        ("autoreply", "watch", "autoreact", "notify", "jobs", "jobdel"),
    ),
    "audit": (
        "🔎 Audit خصوصی",
        "لاگ پیام، ویرایش و حذف برای چت‌های انتخابی",
        ("audit on", "audit off", "audit list", "audit status", "audit purge", "audit test"),
    ),
    "ai": (
        "🤖 هوش مصنوعی",
        "پرسش، راهنمای هوشمند سلف، دستیار موقعیت‌سنج، خلاصهٔ گپ، ترجمه، صدا↔متن و AFK هوشمند (API رایگان)",
        ("ask", "guide", "aiguide on", "aiknow", "sum", "tr", "trauto", "stt", "tts", "ai status", "ai afk on"),
    ),
    "dl": (
        "⬇️ دانلودر",
        "دانلود از یوتیوب، اینستاگرام و تیک‌تاک (ویدیو، MP3، کیفیت دلخواه)",
        ("dl لینک", "dl 480 لینک", "dl audio لینک", "dl me لینک", "dl info لینک", "yt / ig / tt", "دانلود لینک", "dl status"),
    ),
    "groupguard": (
        "🛡 گروه‌داری پیشرفته",
        "کپچا، بلک‌لیست، گزارش فعالیت و پاکسازی",
        ("captcha on", "blacklist add", "blacklist sweep", "activity", "delmes"),
    ),
    "shortcuts": (
        "🧩 میانبر و سفارشی‌سازی",
        "ماکرو، دستورهای فارسی، غیرفعال‌سازی هر گپ، سلامت و بکاپ",
        ("start", "macro add", "m", "alias list", "disable", "enable", "health", "autobackup on", "restore"),
    ),
    "channels": (
        "📢 کانال‌ها",
        "کامنت و ابزارهای مرتبط با کانال",
        ("comment", "comment first", "comments"),
    ),
}


def _now() -> str:
    try:
        zone = ZoneInfo(TIMEZONE)
    except Exception:
        zone = ZoneInfo("UTC")
    return datetime.now(zone).strftime("%Y-%m-%d %H:%M:%S")


def _home_buttons():
    return [
        [Button.inline("📊 داشبورد", b"ui:dash"), Button.inline("⚡ اکشن‌های زنده", b"ui:act")],
        [Button.inline("✂️ سنگ‌کاغذ‌قیچی ۲نفره", b"ui:game:rps"), Button.inline("❌⭕ XO ۲نفره", b"ui:game:xo")],
        [Button.inline("✨ Plus", b"ui:sec:plus"), Button.inline("⚡ ابزار قدرتی", b"ui:sec:power")],
        [Button.inline("🛡 مدیریت", b"ui:sec:admin"), Button.inline("🔐 امنیت", b"ui:sec:security")],
        [Button.inline("🤝 دوست/دشمن", b"ui:sec:relations"), Button.inline("👥 چت", b"ui:sec:chat")],
        [Button.inline("🧠 شخصی", b"ui:sec:personal"), Button.inline("💰 بازار", b"ui:market")],
        [Button.inline("🧰 ابزار", b"ui:sec:tools"), Button.inline("🎞️ مدیا", b"ui:sec:media")],
        [Button.inline("🧹 پیام", b"ui:sec:message"), Button.inline("🎲 بازی", b"ui:sec:games")],
        [Button.inline("⏰ اتوماسیون", b"ui:sec:automation"), Button.inline("📢 کانال", b"ui:sec:channels")],
        [Button.inline("🤖 هوش مصنوعی", b"ui:sec:ai"), Button.inline("⬇️ دانلودر", b"ui:sec:dl")],
        [Button.inline("🛡 گروه‌داری+", b"ui:sec:groupguard")],
        [Button.inline("🧩 میانبر", b"ui:sec:shortcuts"), Button.inline("🔎 Audit خصوصی", b"ui:sec:audit")],
        [Button.inline("ℹ️ درباره", b"ui:about")],
        [Button.inline("⚙️ سیستم", b"ui:system"), Button.inline("💵 قیمت سریع", b"ui:quick")],
        [Button.inline("📄 Help.txt", b"ui:helpfile")],
    ]


def _nav_buttons(back: str = "ui:home"):
    return [[Button.inline("⬅️ برگشت", back.encode()), Button.inline("🏠 خانه", b"ui:home")]]


def _home_text() -> str:
    return (
        "<b>🧩 Hāpoyi UserBot</b>\n\n"
        "مرکز کنترل سلف آماده‌ست. 😎\n"
        "از دکمه‌ها وارد هر بخش شو؛ لازم نیست اسم تک‌تک دستورها یادت بمونه.\n\n"
        "<b>حالت اجرا:</b> UserBot + Assistant UI\n"
        f"<b>Prefix:</b> <code>{PREFIX}</code>\n"
        f"<b>زمان:</b> <code>{_now()}</code>"
    )


# Sections that additionally get a button panel (the command list text above them is kept as is).
SECTION_PANELS = {
    "relations": [("🤝 پنل دوست/دشمن", "ui:p:rel")],
    "admin": [("🛡 پنل گروه", "ui:p:g")],
    "chat": [("🛡 پنل گروه (خوش‌آمد/قفل/لینک)", "ui:p:g")],
    "security": [("🔐 پنل امنیت", "ui:p:sec"), ("🛡 پنل گروه", "ui:p:g")],
    "automation": [("⏰ پنل اتوماسیون", "ui:p:auto"), ("🔁 every", "ui:ev"), ("🤖 AutoReply", "ui:ar")],
    "message": [("⏳ حذف‌های زمان‌بندی‌شده", "ui:p:auto:dj")],
    "media": [("🎞️ ابزار مدیا", "ui:p:media")],
    "personal": [("🌙 AFK", "ui:afk"), ("✅ Todo", "ui:td")],
}


def _section_text(key: str) -> str:
    title, description, commands = SECTIONS[key]
    lines = [f"<b>{title}</b>", "", description, "", "<b>دستورها:</b>"]
    for command in commands:
        lines.append(f"• <code>{PREFIX}{command}</code>")
    lines.extend(["", "برای اجرای دستور، آن را در همان چت بفرست."])
    return "\n".join(lines)


def _section_buttons(key: str):
    # Command names are shown as text (a user account cannot send callback buttons itself); the games section
    # additionally gets real play buttons, because the menu message is posted by the Assistant Bot.
    if key == "games":
        return [[Button.inline("✂️ سنگ‌کاغذ‌قیچی ۲نفره", b"ui:game:rps"), Button.inline("❌⭕ XO ۲نفره", b"ui:game:xo")], *_nav_buttons()]
    panels = SECTION_PANELS.get(key)
    if panels:
        return [[Button.inline(label, data.encode()) for label, data in panels[i:i + 2]] for i in range(0, len(panels), 2)] + _nav_buttons()
    return _nav_buttons()


def _quick_buttons():
    return [
        [Button.inline("💵 دلار", b"ui:q:USD"), Button.inline("₿ BTC", b"ui:q:BTC")],
        [Button.inline("♦️ ETH", b"ui:q:ETH"), Button.inline("◎ SOL", b"ui:q:SOL")],
        [Button.inline("💎 USDT", b"ui:q:USDT"), Button.inline("💠 TON", b"ui:q:TON")],
        [Button.inline("⬅️ برگشت", b"ui:home")],
    ]


def _about_text() -> str:
    return (
        "<b>🧩 Hāpoyi UserBot</b>\n\n"
        "یک UserBot ماژولار بر پایهٔ Telethon.\n"
        "این پیام و دکمه‌ها از Assistant Bot می‌آیند و عملیات واقعی روی UserBot اجرا می‌شود.\n\n"
        "🔒 Callbackها فقط برای Owner پذیرفته می‌شوند.\n"
        f"🕐 {_now()}"
    )


def _system_text(user_client: Any = None) -> str:
    summary = "وضعیت ماژول‌ها در دسترس نیست"
    if user_client is not None:
        registry = getattr(user_client, "_hapoyi_registry", None)
        if registry is not None:
            try:
                summary = registry.summary()
            except Exception:
                pass
    return (
        "<b>⚙️ وضعیت سیستم</b>\n\n"
        "🟢 Assistant UI: فعال\n"
        f"🧩 {summary}\n"
        "🗄️ SQLite: فعال\n"
        "📡 Telethon: 1.45.x\n"
        f"🕐 {_now()}"
    )


async def _render_market() -> str:
    provider = MarketProvider()
    fx = FXProvider(cache_seconds=60)
    symbols = ["BTC", "ETH", "SOL", "USDT", "TON"]
    rows = ["<b>💰 Market Dashboard</b>", ""]
    for symbol in symbols:
        try:
            if symbol == "USDT":
                q = await provider.quote(symbol)
            else:
                q = await provider.quote(symbol)
            toman = f"{q.toman:,.0f} تومان" if q.toman is not None else "—"
            change = "—" if q.change_24h is None else f"{q.change_24h:+.2f}%"
            rows.append(f"<b>{q.symbol}</b>  ${q.usd:,.6f}  |  {toman}  |  {change}")
        except Exception as exc:
            rows.append(f"<b>{symbol}</b>  ❌ {exc.__class__.__name__}")
    try:
        usd = await fx.usd_to_irr()
        rows.append("")
        rows.append(f"💵 USD: {usd / 10:,.0f} تومان")
    except Exception:
        pass
    rows.extend(["", f"🕐 {_now()}"])
    return "\n".join(rows)


async def _send_menu(event, client=None) -> None:
    """Post the menu into the current chat.

    1) Inline mode (preferred): the user account asks the Assistant Bot for the "menu" inline result and
       clicks it - works in ANY chat/PV/group, the bot does not have to be a member.
    2) Fallback: the bot posts it itself (needs the bot in the chat).
    """
    if _bot is None:
        await event.reply(
            "❌ منوی دکمه‌ای فعال نیست.\n"
            "در .env مقدار BOT_TOKEN مربوط به Assistant Bot را تنظیم کن و سلف را ری‌استارت کن."
        )
        return
    posted = False
    try:  # chat-scoped panels (group / security) act on the chat the menu was opened in
        from core.identity import my_id as _my_id
        from modules import ui_panels

        if client is not None and event.chat_id:
            ui_panels.CHAT_CTX[int(await _my_id(client))] = int(event.chat_id)
    except Exception:  # noqa: BLE001
        pass
    if client is not None:
        try:
            from utils.inline_launch import post_inline

            await post_inline(client, _bot, "menu", event.chat_id, getattr(event, "reply_to_msg_id", None))
            posted = True
        except Exception as exc:  # noqa: BLE001
            log.info("inline menu failed (%s: %s); falling back to bot.send_message", exc.__class__.__name__, exc)
    if not posted:
        try:
            await _bot.send_message(event.chat_id, _home_text(), parse_mode="html", buttons=_home_buttons())
            posted = True
        except Exception as exc:  # noqa: BLE001
            await event.reply(
                "❌ Assistant Bot نتوانست منو را اینجا بفرستد.\n"
                f"{exc.__class__.__name__}: {exc}\n\n"
                "راه حل: در @BotFather دستور /setinline بزن و Inline را برای بات روشن کن "
                "(بعدش منو در هر چتی، حتی بدون عضویت بات، با یک کلیک میاد) یا بات را عضو گروه کن."
            )
    if posted and getattr(event, "out", False):
        try:
            await event.delete()
        except Exception:  # noqa: BLE001
            pass


async def setup(client, db):
    from telethon import events as user_events

    @client.on(user_events.NewMessage(outgoing=True, pattern=rf"^{re.escape(PREFIX)}menu$"))
    async def menu_cmd(event):
        await _send_menu(event, client)

    @client.on(user_events.NewMessage(outgoing=True, pattern=rf"^{re.escape(PREFIX)}panel$"))
    async def panel_cmd(event):
        await _send_menu(event, client)


def attach(bot, fleet) -> None:
    """Called once by the control bot: the assistant menu shares that bot (one BOT_TOKEN, one session)
    and answers every running account's owner - nobody else."""
    global _bot, _fleet
    _bot, _fleet = bot, fleet
    from modules import rps_duel
    rps_duel.attach(bot, fleet)
    from modules import xo_duel
    xo_duel.attach(bot, fleet)
    if UI_ENABLED:
        bot.add_event_handler(_callback, events.CallbackQuery(pattern=rb"ui:.*"))
        bot.add_event_handler(_on_inline_menu, events.InlineQuery(pattern=r"^(menu|rps|xo)?\s*$"))


async def _on_inline_menu(event):
    """`@YourBot` / `@YourBot menu|rps|xo` typed (or requested by `.menu`) by an account owner in ANY chat."""
    rt = _fleet.runtime_for_user(event.sender_id) if _fleet is not None else None
    if rt is None:  # strangers get nothing
        return await event.answer([], cache_time=0)
    kind = (event.pattern_match.group(1) or "").lower()
    sender = await event.get_sender()
    name = " ".join(x for x in (getattr(sender, "first_name", None), getattr(sender, "last_name", None)) if x) or "؟"
    from modules import rps_duel, xo_duel

    results = []
    if kind in ("", "menu"):
        results.append(event.builder.article("🧩 منوی Hāpoyi", text=_home_text(), parse_mode="html", buttons=_home_buttons(),
                                             description="داشبورد، اکشن‌های زنده، بازی‌ها و راهنما"))
    if kind in ("", "rps"):
        g = rps_duel.new_duel(event.sender_id, name)
        results.append(event.builder.article("✂️ سنگ‌کاغذ‌قیچی دو نفره", text=g.body(), parse_mode="html",
                                             buttons=rps_duel._buttons(g.token), description="بهترین از ۳"))
    if kind in ("", "xo"):
        x = xo_duel.new_game(event.sender_id, name)
        results.append(event.builder.article("❌⭕ XO دو نفره", text=x.body(), parse_mode="html", buttons=x.buttons(),
                                             description="دوز؛ نوبتی با دکمه"))
    await event.answer(results, cache_time=0, private=True)


# ====================================================================== live (interactive) menu
def _e(text: Any) -> str:
    import html as _html
    return _html.escape(str(text))


def _act_buttons():
    return [
        [Button.inline("🌙 AFK روشن/خاموش", b"ui:afk"), Button.inline("🏓 Ping", b"ui:ping")],
        [Button.inline("🔁 عملیات every", b"ui:ev"), Button.inline("🤖 AutoReply", b"ui:ar")],
        [Button.inline("✅ Todo", b"ui:td"), Button.inline("🌱 عادت‌ها", b"ui:hb")],
        [Button.inline("💸 هزینه‌ها", b"ui:sp"), Button.inline("📬 خوانده‌نشده", b"ui:unread")],
        [Button.inline("💾 بکاپ → Saved Messages", b"ui:backup"), Button.inline("⛔ خاموش‌کردن همهٔ فیک‌ها", b"ui:fakestop")],
        [Button.inline("⬅️ برگشت", b"ui:home")],
    ]


async def _count(db, sql: str, params=()) -> int:
    try:
        row = await db.fetchone(sql, params)
        return int(row[0]) if row else 0
    except Exception:  # noqa: BLE001
        return 0


def _local_now() -> datetime:
    try:
        return datetime.now(ZoneInfo(TIMEZONE))
    except Exception:  # noqa: BLE001
        return datetime.now(ZoneInfo("UTC"))


async def _dashboard(rt) -> str:
    db = rt.db
    uid = await my_id(rt.client)
    afk = await db.fetchone("SELECT reason FROM afk WHERE owner_id=? AND enabled=1", (uid,))
    every_on = await _count(db, "SELECT COUNT(*) FROM repeat_jobs WHERE enabled=1")
    every_all = await _count(db, "SELECT COUNT(*) FROM repeat_jobs")
    ar_on = await _count(db, "SELECT COUNT(*) FROM autoreplies WHERE enabled=1")
    friends = await _count(db, "SELECT COUNT(*) FROM relations WHERE kind='friend'")
    enemies = await _count(db, "SELECT COUNT(*) FROM relations WHERE kind='enemy'")
    todos = await _count(db, "SELECT COUNT(*) FROM todos WHERE done=0")
    notes = await _count(db, "SELECT COUNT(*) FROM notes")
    alerts = await _count(db, "SELECT COUNT(*) FROM price_alerts WHERE enabled=1")
    habits = await _count(db, "SELECT COUNT(*) FROM plus_habits")
    spends = await _count(db, "SELECT COUNT(*) FROM plus_expenses")
    lines = [
        "<b>📊 داشبورد</b>", "",
        f"👤 اکانت: <b>{_e(rt.label)}</b>",
        f"🌙 AFK: {'روشن' if afk else 'خاموش'}",
        f"🔁 every فعال: {every_on} / {every_all}",
        f"🤖 AutoReply فعال: {ar_on}",
        f"🤝 دوست/دشمن: {friends} / {enemies}",
        f"✅ Todo باز: {todos}",
        f"📝 یادداشت: {notes}",
        f"⏰ هشدار قیمت: {alerts}",
        f"🌱 عادت‌ها: {habits}  |  💸 هزینه‌ها: {spends}",
        "", f"🧩 {rt.registry.summary()}", f"🕐 {_now()}",
    ]
    return "\n".join(lines)


async def _live(event, rt, data: str) -> bool:
    """Interactive actions. Everything reads/writes ONLY this account's own database (rt.db)."""
    db, client = rt.db, rt.client
    nav = [[Button.inline("⬅️ اکشن‌ها", b"ui:act"), Button.inline("🏠 خانه", b"ui:home")]]

    async def show(text: str, rows: list | None = None):
        await event.edit(text[:3900], parse_mode="html", buttons=(rows or []) + nav)

    if data == "ui:dash":
        await show(await _dashboard(rt), [[Button.inline("🔄 تازه‌سازی", b"ui:dash")]])
    elif data == "ui:act":
        await event.edit("<b>⚡ اکشن‌های زنده</b>\n\nهر دکمه همین الان روی اکانت تو اجرا می‌شه:", parse_mode="html", buttons=_act_buttons())
    elif data == "ui:afk":
        uid = await my_id(client)
        row = await db.fetchone("SELECT enabled FROM afk WHERE owner_id=?", (uid,))
        if row and row["enabled"]:
            await db.execute("UPDATE afk SET enabled=0 WHERE owner_id=?", (uid,))
            await db.execute("DELETE FROM afk_notified WHERE owner_id=?", (uid,))
            await event.answer("🌙 AFK خاموش شد")
        else:
            from datetime import datetime as _dt, timezone as _tz
            await db.execute("INSERT INTO afk(owner_id,reason,started_at,enabled) VALUES(?,?,?,1) ON CONFLICT(owner_id) DO UPDATE SET started_at=excluded.started_at,enabled=1",
                             (uid, "", _dt.now(_tz.utc).isoformat()))
            await db.execute("DELETE FROM afk_notified WHERE owner_id=?", (uid,))
            await event.answer("🌙 AFK روشن شد")
        await event.edit("<b>⚡ اکشن‌های زنده</b>", parse_mode="html", buttons=_act_buttons())
    elif data == "ui:ping":
        import time as _t
        from telethon.tl.functions import PingRequest
        t0 = _t.monotonic()
        await client(PingRequest(ping_id=int(t0 * 1000)))
        await event.answer(f"🏓 {(_t.monotonic() - t0) * 1000:.0f} ms", alert=True)
    elif data == "ui:fakestop":
        stop = getattr(client, "_hapoyi_fake_stop_all", None)
        n = await stop() if stop else 0
        await event.answer(f"⛔ {n} فیک خاموش شد" if n else "فیک فعالی نبود", alert=True)
    elif data == "ui:backup":
        import os as _os, tempfile as _tf
        fd, path = _tf.mkstemp(suffix=".db", prefix="hapoyi_backup_")
        _os.close(fd)
        try:
            await db.backup_to(path)
            await client.send_file("me", path, caption="💾 Hāpoyi database backup (از منو)", file_name="hapoyi_backup.db")
            await event.answer("💾 بکاپ در Saved Messages ذخیره شد ✅", alert=True)
        finally:
            try:
                _os.remove(path)
            except OSError:
                pass
    elif data == "ui:ev" or data.startswith("ui:ev:"):
        if data.startswith("ui:ev:"):
            _, _, action, rid = data.split(":", 3)
            if action == "d":
                await db.execute("DELETE FROM repeat_jobs WHERE id=?", (int(rid),))
            elif action == "p":
                await db.execute("UPDATE repeat_jobs SET enabled=0 WHERE id=?", (int(rid),))
            elif action == "r":
                import time as _t
                await db.execute("UPDATE repeat_jobs SET enabled=1,last_error=NULL,next_run=?+interval_s WHERE id=?", (_t.time(), int(rid)))
            elif action == "pa":
                await db.execute("UPDATE repeat_jobs SET enabled=0")
            elif action == "da":
                await db.execute("DELETE FROM repeat_jobs")
        rows = await db.fetchall("SELECT id,chat_id,text,interval_s,remaining,enabled,sent FROM repeat_jobs ORDER BY id LIMIT 12")
        if not rows:
            return await show("<b>🔁 عملیات every</b>\n\nچیزی فعال نیست.") or True
        btns, lines = [], ["<b>🔁 عملیات every</b>", ""]
        for r in rows:
            left = "∞" if r["remaining"] is None else r["remaining"]
            lines.append(f"#{r['id']} {'🟢' if r['enabled'] else '⏸'} هر {r['interval_s']}s | ارسال {r['sent']} | باقی {left}\n   «{_e(r['text'][:40])}»")
            btns.append([Button.inline(("⏸" if r["enabled"] else "▶️") + f" #{r['id']}", f"ui:ev:{'p' if r['enabled'] else 'r'}:{r['id']}".encode()),
                         Button.inline(f"🗑 #{r['id']}", f"ui:ev:d:{r['id']}".encode())])
        btns.append([Button.inline("⏸ همه", b"ui:ev:pa:0"), Button.inline("🗑 حذف همه", b"ui:ev:da:0")])
        await show("\n".join(lines), btns)
    elif data == "ui:ar" or data.startswith("ui:ar:"):
        if data.startswith("ui:ar:"):
            _, _, action, rid = data.split(":", 3)
            if action == "t":
                await db.execute("UPDATE autoreplies SET enabled=1-enabled WHERE id=?", (int(rid),))
            elif action == "d":
                await db.execute("DELETE FROM autoreplies WHERE id=?", (int(rid),))
        rows = await db.fetchall("SELECT id,trigger,response,enabled FROM autoreplies ORDER BY id LIMIT 12")
        if not rows:
            return await show("<b>🤖 AutoReply</b>\n\nقانونی ثبت نشده (<code>.autoreply add</code>).") or True
        btns, lines = [], ["<b>🤖 AutoReply</b>", ""]
        for r in rows:
            lines.append(f"#{r['id']} {'🟢' if r['enabled'] else '⏸'} «{_e(r['trigger'][:25])}» ← «{_e(r['response'][:30])}»")
            btns.append([Button.inline(("⏸" if r["enabled"] else "▶️") + f" #{r['id']}", f"ui:ar:t:{r['id']}".encode()), Button.inline(f"🗑 #{r['id']}", f"ui:ar:d:{r['id']}".encode())])
        await show("\n".join(lines), btns)
    elif data == "ui:td" or data.startswith("ui:td:"):
        if data.startswith("ui:td:"):
            await db.execute("UPDATE todos SET done=1-done WHERE id=?", (int(data.rsplit(":", 1)[1]),))
        rows = await db.fetchall("SELECT id,text,done FROM todos ORDER BY done,id LIMIT 12")
        if not rows:
            return await show("<b>✅ Todo</b>\n\nخالی (<code>.todo add</code>).") or True
        await show("<b>✅ Todo</b>\nروی هر مورد بزن تا انجام‌شده/نشده بشه:", [[Button.inline(f"{'☑️' if r['done'] else '⬜'} {r['text'][:30]}", f"ui:td:{r['id']}".encode())] for r in rows])
    elif data == "ui:hb" or data.startswith("ui:hb:"):
        today = _local_now().date().isoformat()
        if data.startswith("ui:hb:"):
            await db.execute("INSERT OR IGNORE INTO plus_habit_log(habit_id,day) VALUES(?,?)", (int(data.rsplit(":", 1)[1]), today))
        rows = await db.fetchall("SELECT id,name FROM plus_habits ORDER BY id LIMIT 12")
        if not rows:
            return await show("<b>🌱 عادت‌ها</b>\n\nخالی (<code>.habit add ورزش</code>).") or True
        done = {r["habit_id"] for r in await db.fetchall("SELECT habit_id FROM plus_habit_log WHERE day=?", (today,))}
        await show("<b>🌱 عادت‌ها</b>\nبرای ثبت امروز بزن:", [[Button.inline(f"{'✅' if r['id'] in done else '⬜'} {r['name'][:30]}", f"ui:hb:{r['id']}".encode())] for r in rows])
    elif data == "ui:sp":
        now = _local_now()
        start = now.replace(hour=0, minute=0, second=0, microsecond=0).timestamp()
        month = now.replace(day=1, hour=0, minute=0, second=0, microsecond=0).timestamp()
        d = await db.fetchone("SELECT COALESCE(SUM(amount),0) AS s FROM plus_expenses WHERE ts>=?", (start,))
        m = await db.fetchone("SELECT COALESCE(SUM(amount),0) AS s FROM plus_expenses WHERE ts>=?", (month,))
        cats = await db.fetchall("SELECT category,SUM(amount) AS s FROM plus_expenses WHERE ts>=? GROUP BY category ORDER BY s DESC LIMIT 6", (month,))
        await show(f"<b>💸 هزینه‌ها</b>\n\nامروز: <b>{d['s']:,.0f}</b>\nاین ماه: <b>{m['s']:,.0f}</b>\n\n" + "\n".join(f"• {_e(c['category'])}: {c['s']:,.0f}" for c in cats)
                   + "\n\nثبت: <code>.spend 50k غذا</code>")
    elif data == "ui:unread":
        await event.answer("در حال بررسی…")
        rows = []
        async for dlg in client.iter_dialogs(limit=150):
            if dlg.unread_count:
                rows.append((dlg.unread_count, dlg.name or "?"))
        rows.sort(reverse=True)
        await show("<b>📬 خوانده‌نشده</b>\n\n" + ("\n".join(f"• {_e(n)}: {c}" for c, n in rows[:15]) if rows else "همه‌چیز خوانده شده 🎉"))
    else:
        return False
    return True


async def _callback(event):
    rt = _fleet.runtime_for_user(event.sender_id) if _fleet is not None else None
    if rt is None:
        await event.answer("⛔ این منو فقط برای صاحب سلف است.", alert=True)
        return
    data = event.data.decode("utf-8", errors="ignore") if event.data else ""
    try:
        from modules import ui_panels

        if event.chat_id:  # bot-posted menu: the chat is known
            ui_panels.CHAT_CTX[int(event.sender_id)] = int(event.chat_id)
        if data.startswith("ui:p:") and await ui_panels.handle(event, rt, data):
            return
        if await _live(event, rt, data):
            return
    except Exception as exc:  # noqa: BLE001
        log.exception("ui live action failed")
        await event.answer(f"❌ {exc.__class__.__name__}", alert=True)
        return
    if data in ("ui:game:rps", "ui:game:xo"):
        from modules import rps_duel, xo_duel

        sender = await event.get_sender()
        name = " ".join(x for x in (getattr(sender, "first_name", None), getattr(sender, "last_name", None)) if x) or "؟"
        if data.endswith("rps"):
            g = rps_duel.new_duel(event.sender_id, name)
            await event.edit(g.body(), parse_mode="html", buttons=rps_duel._buttons(g.token))
        else:
            x = xo_duel.new_game(event.sender_id, name)
            await event.edit(x.body(), parse_mode="html", buttons=x.buttons())
        return
    if data == "ui:home":
        await event.edit(_home_text(), parse_mode="html", buttons=_home_buttons())
        return
    if data.startswith("ui:sec:"):
        key = data.split(":", 2)[2]
        if key not in SECTIONS:
            await event.answer("بخش ناشناخته است.", alert=True)
            return
        await event.edit(_section_text(key), parse_mode="html", buttons=_section_buttons(key))
        return
    if data == "ui:about":
        await event.edit(_about_text(), parse_mode="html", buttons=_nav_buttons())
        return
    if data == "ui:helpfile":
        help_path = Path(__file__).resolve().parents[1] / "docs" / "HELP.txt"
        if event.chat_id:
            await _bot.send_file(event.chat_id, help_path, caption="🧩 Hāpoyi UserBot — Help.txt")
        else:  # inline-posted menu: there is no chat id; deliver to the owner's Saved Messages instead
            await rt.client.send_file("me", help_path, caption="🧩 Hāpoyi UserBot — Help.txt")
        await event.answer("Help.txt ارسال شد ✅")
        return
    if data == "ui:system":
        await event.edit(_system_text(rt.client), parse_mode="html", buttons=_nav_buttons())
        return
    if data == "ui:market":
        await event.answer("در حال دریافت قیمت‌ها…")
        await event.edit(await _render_market(), parse_mode="html", buttons=_nav_buttons())
        return
    if data == "ui:quick":
        await event.edit("<b>💵 قیمت سریع</b>\n\nیک دارایی را انتخاب کن:", parse_mode="html", buttons=_quick_buttons())
        return
    if data.startswith("ui:q:"):
        symbol = data.split(":", 2)[2]
        provider = MarketProvider()
        try:
            if symbol == "USD":
                fx = FXProvider(cache_seconds=60)
                irr = await fx.usd_to_irr()
                text = f"<b>💵 دلار / USD</b>\n\n🇮🇷 {irr / 10:,.0f} تومان\n\n🕐 {_now()}"
            else:
                q = await provider.quote(symbol)
                toman = f"{q.toman:,.0f} تومان" if q.toman is not None else "—"
                change = "—" if q.change_24h is None else f"{q.change_24h:+.2f}%"
                text = (
                    f"<b>🪙 {q.symbol}</b>\n\n"
                    f"💵 USD: ${q.usd:,.8f}\n"
                    f"🇮🇷 Toman: {toman}\n"
                    f"📈 24H: {change}\n"
                    f"🕐 {_now()}"
                )
        except Exception as exc:
            text = f"❌ دریافت قیمت ناموفق بود: <code>{exc.__class__.__name__}</code>"
        await event.edit(text, parse_mode="html", buttons=_quick_buttons())
        return
    await event.answer("دکمهٔ نامعتبر.", alert=True)
