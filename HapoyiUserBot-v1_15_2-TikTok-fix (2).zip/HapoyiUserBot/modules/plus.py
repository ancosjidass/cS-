"""Hāpoyi Plus - 15 practical extras. Every account has its OWN data (tables live in that account's database).

 1 .timer      live countdown (custom edit interval)   9 .snip   text snippets
 2 .fake       fake typing/recording (unlimited)      10 .fancy  fancy fonts   (.stop fake all)
 3 .unit       unit converter           11 .hash/.b64 hash + base64
 4 .greet      auto-greet new PVs       12 .wc       word counter
 5 .dnd        quiet-hours auto-reply   13 .pomo     pomodoro
 6 .bday       birthday reminders       14 .quote    personal quotes
 7 .spend      expense tracker          15 .unread   unread chats summary
 8 .habit      habit streaks
"""
from __future__ import annotations

import asyncio
import logging
import os
import random
import re
import time
from datetime import datetime, timedelta
from zoneinfo import ZoneInfo

from telethon import events, types as tl_types
from telethon.errors import FloodWaitError, MessageNotModifiedError
from telethon.tl.functions.messages import SetTypingRequest

from utils.formatting import parse_duration
from utils import plus_helpers as H

log = logging.getLogger(__name__)
PREFIX = os.getenv("COMMAND_PREFIX", ".") or "."
P = re.escape(PREFIX)
TIMEZONE = os.getenv("TIMEZONE", "Asia/Tehran") or "Asia/Tehran"

TABLES = """
CREATE TABLE IF NOT EXISTS plus_snippets (name TEXT PRIMARY KEY, text TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS plus_quotes (id INTEGER PRIMARY KEY AUTOINCREMENT, text TEXT NOT NULL, author TEXT, ts REAL NOT NULL);
CREATE TABLE IF NOT EXISTS plus_expenses (id INTEGER PRIMARY KEY AUTOINCREMENT, amount REAL NOT NULL, category TEXT NOT NULL, note TEXT, ts REAL NOT NULL);
CREATE TABLE IF NOT EXISTS plus_habits (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL UNIQUE, created REAL NOT NULL);
CREATE TABLE IF NOT EXISTS plus_habit_log (habit_id INTEGER NOT NULL, day TEXT NOT NULL, PRIMARY KEY(habit_id, day));
CREATE TABLE IF NOT EXISTS plus_birthdays (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, month INTEGER NOT NULL, day INTEGER NOT NULL, year INTEGER);
CREATE TABLE IF NOT EXISTS plus_greeted (user_id INTEGER PRIMARY KEY, ts REAL NOT NULL);
CREATE TABLE IF NOT EXISTS plus_dnd_seen (user_id INTEGER NOT NULL, window_day TEXT NOT NULL, PRIMARY KEY(user_id, window_day));
"""

# name -> Telethon action factory. Telegram shows an action for ~5-6 s, so we re-send it every FAKE_REFRESH seconds.
FAKE_ACTIONS = {
    "typing": lambda: tl_types.SendMessageTypingAction(), "type": lambda: tl_types.SendMessageTypingAction(),
    "voice": lambda: tl_types.SendMessageRecordAudioAction(), "audio": lambda: tl_types.SendMessageRecordAudioAction(),
    "video": lambda: tl_types.SendMessageRecordVideoAction(), "round": lambda: tl_types.SendMessageRecordRoundAction(),
    "game": lambda: tl_types.SendMessageGamePlayAction(),
    "photo": lambda: tl_types.SendMessageUploadPhotoAction(50),
    "file": lambda: tl_types.SendMessageUploadDocumentAction(50), "document": lambda: tl_types.SendMessageUploadDocumentAction(50),
    "sticker": lambda: tl_types.SendMessageChooseStickerAction(),
    "location": lambda: tl_types.SendMessageGeoLocationAction(), "contact": lambda: tl_types.SendMessageChooseContactAction(),
}
FAKE_CANON = {"type": "typing", "audio": "voice", "document": "file"}
FAKE_REFRESH = 4.0
FAKE_MAX_RUNNING = 40
INFINITE_WORDS = {"", "inf", "infinite", "forever", "unlimited", "∞", "نامحدود", "بینهایت", "همیشه"}
MAX_TIMER_SECONDS = 24 * 3600
MIN_TIMER_STEP = 1
HELP = (
    "✨ Hāpoyi Plus\n"
    f"`{PREFIX}timer 5m [10s] [متن]` شمارش معکوس زنده؛ عدد دوم = هر چند ثانیه یک‌بار پیام ادیت شود | `{PREFIX}timer stop`\n"
    f"`{PREFIX}fake typing|voice|video|round|game|photo|file|sticker|location|contact [30s|10m|inf]` ادای تایپ/ضبط (بدون زمان = نامحدود)\n"
    f"`{PREFIX}fake list` | `{PREFIX}stop fake [نوع]` (همین چت) | `{PREFIX}stop fake all` (همهٔ فیک‌ها در همه‌ی چت‌ها)\n"
    f"`{PREFIX}unit 5 km mi` تبدیل واحد (طول/وزن/حجم/سرعت/دما/دیتا)\n"
    f"`{PREFIX}greet on|off|set <متن>|status` خوش‌آمد خودکار به پیوی‌های جدید\n"
    f"`{PREFIX}dnd 23:00-07:00 [متن]|off|status` مزاحم نشو (پاسخ خودکار پیوی)\n"
    f"`{PREFIX}bday add <نام> <ماه-روز>|list|del <id>` یادآور تولد (به Saved Messages)\n"
    f"`{PREFIX}spend 50k غذا ناهار` | `today|week|month|list|undo|del <id>` ثبت هزینه\n"
    f"`{PREFIX}habit add <نام>|done <id>|list|del <id>` عادت‌ها و streak\n"
    f"`{PREFIX}snip add <نام> <متن>` | `{PREFIX}snip <نام>` | `list|del` تکه‌متن آماده\n"
    f"`{PREFIX}fancy bold|italic|mono|script|circle|wide|small|flip|strike|under متن` (یا Reply)\n"
    f"`{PREFIX}hash [md5|sha1|sha256|sha512] متن` | `{PREFIX}b64 enc|dec متن`\n"
    f"`{PREFIX}wc` (Reply یا متن) شمارش کلمه/حرف و زمان مطالعه\n"
    f"`{PREFIX}pomo [کار] [استراحت]` پومودورو (دقیقه) | `{PREFIX}pomo stop`\n"
    f"`{PREFIX}quote add (Reply)|list|del <id>` | `{PREFIX}quote` یک نقل‌قول تصادفی\n"
    f"`{PREFIX}unread [N]` چت‌های خوانده‌نشده"
)


async def setup(client, db):
    for stmt in filter(None, (s.strip() for s in TABLES.split(";"))):
        await db.execute(stmt)

    try:
        zone = ZoneInfo(TIMEZONE)
    except Exception:  # noqa: BLE001
        zone = ZoneInfo("UTC")

    def now_local() -> datetime:
        return datetime.now(zone)

    def cmd(pattern: str, flags: str = ""):
        return events.NewMessage(outgoing=True, pattern=rf"{flags}^{P}{pattern}$")

    async def arg_or_reply(event, arg: str | None) -> str:
        arg = (arg or "").strip()
        if arg:
            return arg
        if event.is_reply:
            m = await event.get_reply_message()
            return (getattr(m, "message", "") or "").strip() if m else ""
        return ""

    state: dict[str, object] = {"timers": {}, "pomo": None, "fakes": {}}

    @client.on(cmd(r"plus"))
    async def plus_help(event):
        await event.reply(HELP)

    # ------------------------------------------------------------------ 1. timer
    def _parse_step(token: str) -> int | None:
        """'10s' / '10' (seconds) / '1m' -> seconds, None when the token is not an interval."""
        token = token.strip().lower()
        if token.isdigit():
            return int(token)
        try:
            return parse_duration(token)
        except ValueError:
            return None

    def auto_step(left: float) -> float:
        return 5 if left <= 120 else 30 if left <= 3600 else 60

    @client.on(cmd(r"timer(?:\s+(.+))?", "(?s)"))
    async def timer(event):
        raw = (event.pattern_match.group(1) or "").strip()
        timers: dict = state["timers"]  # type: ignore[assignment]
        if raw in ("stop", "cancel", "off"):
            n = len(timers)
            for t in list(timers.values()):
                t.cancel()
            timers.clear()
            return await event.reply(f"⏹ {n} تایمر متوقف شد." if n else "⏹ تایمر فعالی نبود.")
        parts = raw.split(None, 1)
        try:
            seconds = parse_duration(parts[0]) if parts else 0
        except ValueError:
            seconds = 0
        usage = (f"فرمت: `{PREFIX}timer 5m [10s] [متن]`\n"
                 f"• عدد دوم (اختیاری) = هر چند ثانیه یک‌بار پیام ادیت شود (مثلاً `{PREFIX}timer 5m 10s استراحت`)\n"
                 f"• بدون آن، فاصله خودکار است (۵ ثانیه، بعد ۳۰ ثانیه، بعد ۱ دقیقه)\n"
                 f"• حداکثر ۲۴ ساعت | حداقل فاصلهٔ ادیت {MIN_TIMER_STEP} ثانیه")
        if not seconds or seconds > MAX_TIMER_SECONDS:
            return await event.reply(usage)
        # optional 2nd token = edit interval   (`every 10s`, `هر 10s`, `10s`, `10`)
        step: int | None = None
        label = "تایمر"
        if len(parts) > 1:
            rest = parts[1].strip()
            toks = rest.split(None, 1)
            if toks and toks[0].lower() in {"every", "هر", "@", "-i"} and len(toks) > 1:
                toks = toks[1].split(None, 1)
                cand = _parse_step(toks[0]) if toks else None
                if cand is None:
                    return await event.reply(usage)
                step, label = cand, (toks[1].strip() if len(toks) > 1 else "تایمر")
            else:
                cand = _parse_step(toks[0]) if toks else None
                if cand is not None:
                    step, label = cand, (toks[1].strip() if len(toks) > 1 else "تایمر")
                else:
                    label = rest
        if step is not None and not MIN_TIMER_STEP <= step <= seconds:
            return await event.reply(f"❌ فاصلهٔ ادیت باید بین {MIN_TIMER_STEP} ثانیه و کل زمان تایمر باشد.\n\n{usage}")
        if len(timers) >= 5:
            return await event.reply("❌ حداکثر ۵ تایمر هم‌زمان.")
        end = time.time() + seconds
        suffix = f"\n🔄 هر {step} ثانیه آپدیت می‌شود" if step else ""

        def render(left: float) -> str:
            return f"⏳ {label}: {fmt_clock(left)}{suffix}"

        msg = await event.edit(render(seconds))

        async def run():
            try:
                while True:
                    left = end - time.time()
                    if left <= 0:
                        break
                    # never overshoot the end: the last sleep lands exactly on 0
                    await asyncio.sleep(max(0.2, min(step or auto_step(left), left)))
                    left = end - time.time()
                    if left <= 0.5:
                        break
                    try:
                        await msg.edit(render(left))
                    except MessageNotModifiedError:
                        pass
                    except FloodWaitError as exc:
                        await asyncio.sleep(exc.seconds + 1)
                    except Exception as exc:  # noqa: BLE001
                        if exc.__class__.__name__ in {"MessageIdInvalidError", "MessageAuthorRequiredError"}:
                            return  # message deleted: stop quietly
                try:
                    await msg.edit(f"⏰ {label}: تمام شد!")
                except Exception:  # noqa: BLE001
                    pass
                await client.send_message("me", f"⏰ تایمر «{label}» تمام شد.")
            except asyncio.CancelledError:
                raise
            finally:
                timers.pop(id(msg), None)

        timers[id(msg)] = asyncio.get_running_loop().create_task(run())

    def fmt_clock(sec: float) -> str:
        sec = int(round(sec))
        h, r = divmod(sec, 3600)
        m, s = divmod(r, 60)
        return f"{h:02d}:{m:02d}:{s:02d}" if h else f"{m:02d}:{s:02d}"

    # ------------------------------------------------------------------ 2. fake actions (unlimited)
    fakes: dict[tuple[int, str], asyncio.Task] = state["fakes"]  # type: ignore[assignment]

    async def _fake_loop(chat_id: int, name: str, seconds: float | None) -> None:
        """Re-send the chat action every FAKE_REFRESH s. `seconds=None` -> until stopped. Survives flood waits / reconnects."""
        try:
            peer = await client.get_input_entity(chat_id)
        except Exception as exc:  # noqa: BLE001
            fakes.pop((chat_id, name), None)
            log.warning("fake %s: cannot resolve chat %s: %s", name, chat_id, exc.__class__.__name__)
            return
        deadline = None if seconds is None else time.monotonic() + seconds
        try:
            while deadline is None or time.monotonic() < deadline:
                try:
                    await client(SetTypingRequest(peer, FAKE_ACTIONS[name]()))
                except FloodWaitError as exc:
                    await asyncio.sleep(exc.seconds + 1)
                    continue
                except (ConnectionError, TimeoutError, asyncio.TimeoutError, OSError):
                    await asyncio.sleep(5)  # network blip: keep going
                    continue
                except Exception as exc:  # noqa: BLE001
                    if exc.__class__.__name__ in {"ChatWriteForbiddenError", "UserBannedInChannelError", "ChannelPrivateError", "PeerIdInvalidError"}:
                        log.info("fake %s stopped in %s: %s", name, chat_id, exc.__class__.__name__)
                        return
                    log.warning("fake action: %s: %s", exc.__class__.__name__, exc)
                    await asyncio.sleep(5)
                    continue
                wait = FAKE_REFRESH if deadline is None else min(FAKE_REFRESH, max(0.0, deadline - time.monotonic()))
                await asyncio.sleep(wait)
        finally:
            fakes.pop((chat_id, name), None)
            try:  # cancel (also on shutdown); best effort, never raises out of finally
                await asyncio.shield(client(SetTypingRequest(peer, tl_types.SendMessageCancelAction())))
            except BaseException:  # noqa: BLE001
                pass

    async def stop_fakes(chat_id: int | None = None, name: str | None = None) -> int:
        victims = [(k, t) for k, t in list(fakes.items()) if (chat_id is None or k[0] == chat_id) and (name is None or k[1] == name)]
        for k, t in victims:
            t.cancel()
        if victims:
            await asyncio.gather(*[t for _, t in victims], return_exceptions=True)
        return len(victims)

    client._hapoyi_fake_stop_all = stop_fakes  # used by the menu button

    @client.on(cmd(r"fake(?:\s+(\S+))?(?:\s+(\S+))?"))
    async def fake(event):
        word = (event.pattern_match.group(1) or "").lower()
        if word in {"list", "status"}:
            if not fakes:
                return await event.reply("🎭 فیک فعالی نیست.")
            lines = [f"🎭 فیک‌های فعال ({len(fakes)})"] + [f"• {FAKE_CANON.get(n, n)} — chat {c}" for c, n in fakes]
            return await event.reply("\n".join(lines))
        if word in {"stop", "off", "cancel"}:
            arg = (event.pattern_match.group(2) or "").lower()
            if arg == "all":
                n = await stop_fakes()
                return await event.reply(f"⏹ همهٔ فیک‌ها خاموش شد ({n}).")
            n = await stop_fakes(event.chat_id, FAKE_CANON.get(arg, arg) if arg in FAKE_ACTIONS else None)
            return await event.reply(f"⏹ {n} فیک در این چت خاموش شد.")
        action = word if word in FAKE_ACTIONS else None
        dur = (event.pattern_match.group(2) or "").strip().lower()
        seconds: int | None
        if dur in INFINITE_WORDS:
            seconds = None
        else:
            try:
                seconds = parse_duration(dur)
            except ValueError:
                seconds = 0
        if not action or seconds == 0:
            return await event.reply(
                f"فرمت: `{PREFIX}fake typing|voice|video|round|game|photo|file|sticker|location|contact [30s|10m|2h|inf]`\n"
                f"بدون زمان = نامحدود تا وقتی `{PREFIX}stop fake all` بزنی. | `{PREFIX}fake list`")
        action = FAKE_CANON.get(action, action)
        chat_id = event.chat_id
        if (chat_id, action) not in fakes and len(fakes) >= FAKE_MAX_RUNNING:
            return await event.reply(f"❌ حداکثر {FAKE_MAX_RUNNING} فیک هم‌زمان؛ با `{PREFIX}stop fake all` پاک کن.")
        await stop_fakes(chat_id, action)  # same chat + same action: restart with the new duration
        await event.delete()
        # background: never block the (sequential) update loop
        fakes[(chat_id, action)] = asyncio.get_running_loop().create_task(_fake_loop(chat_id, action, seconds))

    @client.on(cmd(r"stop\s+fake(?:\s+(\S+))?"))
    async def stop_fake(event):
        arg = (event.pattern_match.group(1) or "").lower()
        if arg == "all":
            n = await stop_fakes()
            return await event.reply(f"⏹ همهٔ فیک‌ها خاموش شد ({n}).")
        if arg and arg not in FAKE_ACTIONS:
            return await event.reply(f"فرمت: `{PREFIX}stop fake all` (همه) | `{PREFIX}stop fake [نوع]` | `{PREFIX}stop fake` (همین چت)")
        n = await stop_fakes(event.chat_id, FAKE_CANON.get(arg, arg) if arg else None)
        await event.reply(f"⏹ {n} فیک در این چت خاموش شد." if n else "ℹ️ فیک فعالی در این چت نبود. (`.stop fake all` = همه‌ی چت‌ها)")

    # ------------------------------------------------------------------ 3. units
    @client.on(cmd(r"unit\s+(\S+)\s+(\S+)\s+(?:to\s+|به\s+)?(\S+)"))
    async def unit(event):
        value = H.parse_amount(event.pattern_match.group(1))
        src, dst = event.pattern_match.group(2), event.pattern_match.group(3)
        out = H.convert_units(value, src, dst) if value is not None else None
        if out is None:
            return await event.reply(f"❌ نشد. مثال: `{PREFIX}unit 5 km mi` | `{PREFIX}unit 100 c f` | `{PREFIX}unit 2 gb mb`")
        await event.reply(f"📐 {value:g} {src} = {out:,.6g} {dst}")

    # ------------------------------------------------------------------ 4. greet (new PVs)
    greet = {"on": bool(await db.get_kv("plus:greet:on", False)),
             "text": await db.get_kv("plus:greet:text", "سلام! الان آنلاین نیستم، به محض اینکه برگردم جواب می‌دم. 🙏")}

    @client.on(cmd(r"greet(?:\s+(on|off|status|set)(?:\s+(.+))?)?", "(?s)"))
    async def greet_cmd(event):
        word, text = event.pattern_match.group(1), (event.pattern_match.group(2) or "").strip()
        if word in ("on", "off"):
            greet["on"] = word == "on"
            await db.set_kv("plus:greet:on", greet["on"])
        elif word == "set":
            if not text:
                return await event.reply(f"فرمت: `{PREFIX}greet set متن`")
            greet["text"] = text[:1000]
            await db.set_kv("plus:greet:text", greet["text"])
        n = await db.fetchone("SELECT COUNT(*) AS n FROM plus_greeted")
        await event.reply(f"👋 Greet: {'روشن ✅' if greet['on'] else 'خاموش ⛔'} | خوش‌آمد داده‌شده: {n['n']}\n«{greet['text']}»")

    # ------------------------------------------------------------------ 5. dnd
    dnd = await db.get_kv("plus:dnd", None) or {"on": False, "start": 0, "end": 0, "text": "الان در حالت مزاحم نشو هستم 🌙 صبح جواب می‌دم."}

    def dnd_active() -> bool:
        if not dnd["on"]:
            return False
        n = now_local()
        return H.in_window(n.hour * 60 + n.minute, int(dnd["start"]), int(dnd["end"]))

    @client.on(cmd(r"dnd(?:\s+(.+))?", "(?s)"))
    async def dnd_cmd(event):
        arg = (event.pattern_match.group(1) or "status").strip()
        if arg == "off":
            dnd["on"] = False
        elif arg != "status":
            m = re.match(r"(\d{1,2}:\d{2})\s*-\s*(\d{1,2}:\d{2})(?:\s+(.+))?$", H.norm_digits(arg), re.S)
            if not m or H.parse_hhmm(m.group(1)) is None or H.parse_hhmm(m.group(2)) is None:
                return await event.reply(f"فرمت: `{PREFIX}dnd 23:00-07:00 [متن پاسخ]` | `{PREFIX}dnd off`")
            dnd.update(on=True, start=H.parse_hhmm(m.group(1)), end=H.parse_hhmm(m.group(2)))
            if m.group(3):
                dnd["text"] = m.group(3).strip()[:1000]
        await db.set_kv("plus:dnd", dnd)
        if dnd["on"]:
            s, e = int(dnd["start"]), int(dnd["end"])
            await event.reply(f"🌙 DND روشن: {s // 60:02d}:{s % 60:02d} تا {e // 60:02d}:{e % 60:02d}"
                              f"{' (الان فعاله)' if dnd_active() else ''}\n«{dnd['text']}»")
        else:
            await event.reply("🌙 DND خاموش است.")

    @client.on(events.NewMessage(incoming=True, func=lambda e: e.is_private))
    async def private_auto(event):
        try:
            sender = await event.get_sender()
            if sender is None or getattr(sender, "bot", False) or getattr(sender, "self", False) or getattr(sender, "id", 0) == 777000:
                return
            uid = int(sender.id)
            if dnd_active():
                n = now_local()
                crossing = int(dnd["start"]) > int(dnd["end"]) and n.hour * 60 + n.minute < int(dnd["end"])
                day = (n - timedelta(days=1) if crossing else n).strftime("%Y-%m-%d")
                if await db.insert("INSERT OR IGNORE INTO plus_dnd_seen(user_id,window_day) VALUES(?,?)", (uid, day)):
                    await event.reply(str(dnd["text"]))
                    return
            if greet["on"] and await db.insert("INSERT OR IGNORE INTO plus_greeted(user_id,ts) VALUES(?,?)", (uid, time.time())):
                history = await client.get_messages(event.chat_id, limit=1)
                if getattr(history, "total", 0) <= 1:  # a brand-new conversation; old chats are never greeted
                    await event.reply(str(greet["text"]))
        except Exception as exc:  # noqa: BLE001
            log.warning("plus private_auto: %s: %s", exc.__class__.__name__, exc)

    # ------------------------------------------------------------------ 6. birthdays
    @client.on(cmd(r"bday(?:\s+(add|list|del))?(?:\s+(.+))?", "(?s)"))
    async def bday(event):
        word, rest = event.pattern_match.group(1) or "list", (event.pattern_match.group(2) or "").strip()
        if word == "add":
            parts = rest.rsplit(None, 1)
            parsed = H.parse_birthday(parts[1]) if len(parts) == 2 else None
            if not parsed:
                return await event.reply(f"فرمت: `{PREFIX}bday add علی 03-12` (ماه-روز، سال اختیاری)")
            await db.insert("INSERT INTO plus_birthdays(name,month,day,year) VALUES(?,?,?,?)", (parts[0][:60], parsed[0], parsed[1], parsed[2]))
            return await event.reply(f"🎂 ثبت شد: {parts[0]} ({parsed[0]:02d}-{parsed[1]:02d})")
        if word == "del":
            if not rest.isdigit():
                return await event.reply(f"فرمت: `{PREFIX}bday del <id>`")
            n = await db.execute("DELETE FROM plus_birthdays WHERE id=?", (int(rest),))
            return await event.reply("✅ حذف شد." if n else "❌ پیدا نشد.")
        rows = await db.fetchall("SELECT * FROM plus_birthdays ORDER BY month,day")
        if not rows:
            return await event.reply("🎂 تولدی ثبت نشده.")
        await event.reply("🎂 تولدها\n" + "\n".join(f"#{r['id']} {r['name']} — {r['month']:02d}-{r['day']:02d}" for r in rows)[:3800])

    async def bday_loop():
        while True:
            try:
                n = now_local()
                today = n.strftime("%Y-%m-%d")
                if n.hour >= 9 and await db.get_kv("plus:bday:last") != today and client.is_connected():
                    rows = await db.fetchall("SELECT name,year FROM plus_birthdays WHERE month=? AND day=?", (n.month, n.day))
                    if rows:
                        lines = [f"🎉 {r['name']}" + (f" ({n.year - r['year']} ساله)" if r["year"] and r["year"] > 1900 else "") for r in rows]
                        await client.send_message("me", "🎂 امروز تولد:\n" + "\n".join(lines))
                    await db.set_kv("plus:bday:last", today)
            except asyncio.CancelledError:
                raise
            except Exception as exc:  # noqa: BLE001
                log.warning("bday loop: %s: %s", exc.__class__.__name__, exc)
            await asyncio.sleep(900)

    asyncio.get_running_loop().create_task(bday_loop())

    # ------------------------------------------------------------------ 7. expenses
    def span_start(kind: str) -> float:
        n = now_local()
        base = n.replace(hour=0, minute=0, second=0, microsecond=0)
        if kind == "week":
            base = base - timedelta(days=n.weekday())
        elif kind == "month":
            base = base.replace(day=1)
        return base.timestamp()

    @client.on(cmd(r"spend(?:\s+(.+))?", "(?s)"))
    async def spend(event):
        arg = (event.pattern_match.group(1) or "").strip()
        word = arg.split(None, 1)[0].lower() if arg else "today"
        if word in ("today", "week", "month", "امروز", "هفته", "ماه"):
            kind = {"امروز": "today", "هفته": "week", "ماه": "month"}.get(word, word)
            rows = await db.fetchall("SELECT category, SUM(amount) AS s, COUNT(*) AS c FROM plus_expenses WHERE ts>=? GROUP BY category ORDER BY s DESC", (span_start(kind),))
            if not rows:
                return await event.reply("💸 هزینه‌ای ثبت نشده.")
            total = sum(r["s"] for r in rows)
            return await event.reply(f"💸 هزینه‌ها ({kind}) — جمع: {H.money(total)}\n" + "\n".join(f"• {r['category']}: {H.money(r['s'])} ({r['c']})" for r in rows))
        if word == "list":
            rows = await db.fetchall("SELECT * FROM plus_expenses ORDER BY id DESC LIMIT 15")
            return await event.reply("🧾 آخرین‌ها\n" + ("\n".join(f"#{r['id']} {H.money(r['amount'])} — {r['category']}" + (f" ({r['note']})" if r["note"] else "") for r in rows) or "خالی"))
        if word == "undo":
            row = await db.fetchone("SELECT id FROM plus_expenses ORDER BY id DESC LIMIT 1")
            if row:
                await db.execute("DELETE FROM plus_expenses WHERE id=?", (row["id"],))
            return await event.reply("↩️ آخرین هزینه حذف شد." if row else "خالی است.")
        if word == "del":
            ident = arg.split()[1] if len(arg.split()) > 1 else ""
            n = await db.execute("DELETE FROM plus_expenses WHERE id=?", (int(ident),)) if ident.isdigit() else 0
            return await event.reply("✅ حذف شد." if n else "❌ پیدا نشد.")
        parts = arg.split(None, 2)
        amount = H.parse_amount(parts[0]) if parts else None
        if amount is None or amount <= 0:
            return await event.reply(f"فرمت: `{PREFIX}spend 50k غذا ناهار` | `{PREFIX}spend today|week|month|list|undo`")
        category = parts[1][:30] if len(parts) > 1 else "متفرقه"
        note = parts[2][:100] if len(parts) > 2 else None
        rid = await db.insert("INSERT INTO plus_expenses(amount,category,note,ts) VALUES(?,?,?,?)", (amount, category, note, time.time()))
        await event.reply(f"💸 #{rid} ثبت شد: {H.money(amount)} — {category}")

    # ------------------------------------------------------------------ 8. habits
    @client.on(cmd(r"habit(?:\s+(add|done|list|del))?(?:\s+(.+))?", "(?s)"))
    async def habit(event):
        word, rest = event.pattern_match.group(1) or "list", (event.pattern_match.group(2) or "").strip()
        today = now_local().date()
        if word == "add":
            if not rest:
                return await event.reply(f"فرمت: `{PREFIX}habit add ورزش`")
            hid = await db.insert("INSERT OR IGNORE INTO plus_habits(name,created) VALUES(?,?)", (rest[:50], time.time()))
            return await event.reply(f"✅ عادت #{hid} اضافه شد." if hid else "ℹ️ این عادت قبلاً هست.")
        if word in ("done", "del"):
            if not rest.isdigit():
                return await event.reply(f"فرمت: `{PREFIX}habit {word} <id>`")
            row = await db.fetchone("SELECT * FROM plus_habits WHERE id=?", (int(rest),))
            if not row:
                return await event.reply("❌ پیدا نشد.")
            if word == "del":
                await db.execute("DELETE FROM plus_habit_log WHERE habit_id=?", (row["id"],))
                await db.execute("DELETE FROM plus_habits WHERE id=?", (row["id"],))
                return await event.reply("🗑 حذف شد.")
            await db.execute("INSERT OR IGNORE INTO plus_habit_log(habit_id,day) VALUES(?,?)", (row["id"], today.isoformat()))
            days = {r["day"] for r in await db.fetchall("SELECT day FROM plus_habit_log WHERE habit_id=?", (row["id"],))}
            return await event.reply(f"🔥 «{row['name']}» انجام شد — streak: {H.streak(days, today)} روز")
        rows = await db.fetchall("SELECT * FROM plus_habits ORDER BY id")
        if not rows:
            return await event.reply("🌱 عادتی ثبت نشده.")
        out = []
        for r in rows:
            days = {x["day"] for x in await db.fetchall("SELECT day FROM plus_habit_log WHERE habit_id=?", (r["id"],))}
            out.append(f"#{r['id']} {'✅' if today.isoformat() in days else '⬜'} {r['name']} — 🔥{H.streak(days, today)}")
        await event.reply("🌱 عادت‌ها\n" + "\n".join(out))

    # ------------------------------------------------------------------ 9. snippets
    @client.on(cmd(r"snip(?:\s+(.+))?", "(?s)"))
    async def snip(event):
        arg = (event.pattern_match.group(1) or "").strip()
        if not arg or arg == "list":
            rows = await db.fetchall("SELECT name FROM plus_snippets ORDER BY name")
            return await event.reply("✂️ " + (" ، ".join(r["name"] for r in rows) if rows else f"تکه‌متنی نیست؛ `{PREFIX}snip add نام متن`"))
        parts = arg.split(None, 2)
        if parts[0] == "add" and len(parts) == 3:
            await db.execute("INSERT INTO plus_snippets(name,text) VALUES(?,?) ON CONFLICT(name) DO UPDATE SET text=excluded.text", (parts[1].lower()[:30], parts[2][:4000]))
            return await event.reply(f"✅ ذخیره شد: {parts[1]}")
        if parts[0] == "del" and len(parts) >= 2:
            n = await db.execute("DELETE FROM plus_snippets WHERE name=?", (parts[1].lower(),))
            return await event.reply("🗑 حذف شد." if n else "❌ پیدا نشد.")
        row = await db.fetchone("SELECT text FROM plus_snippets WHERE name=?", (arg.lower(),))
        if not row:
            return await event.reply("❌ این تکه‌متن وجود ندارد.")
        await event.edit(row["text"])

    # ------------------------------------------------------------------ 10. fancy
    @client.on(cmd(r"fancy(?:\s+(\S+))?(?:\s+(.+))?", "(?s)"))
    async def fancy_cmd(event):
        style, text = (event.pattern_match.group(1) or "").lower(), event.pattern_match.group(2)
        if style in ("", "list"):
            return await event.reply("🔤 " + " | ".join([*H.STYLES, "flip", "reverse"]))
        if style not in H.STYLES and style not in ("flip", "reverse"):
            text, style = f"{style} {text}".strip() if text else style, "bold"
        text = await arg_or_reply(event, text)
        if not text:
            return await event.reply(f"فرمت: `{PREFIX}fancy bold متن` یا روی یک پیام Reply کن.")
        await event.edit(H.fancy(style, text[:3000]) or text)

    # ------------------------------------------------------------------ 11. hash / base64
    @client.on(cmd(r"hash(?:\s+(md5|sha1|sha256|sha512))?(?:\s+(.+))?", "(?s)"))
    async def hash_cmd(event):
        text = await arg_or_reply(event, event.pattern_match.group(2))
        if not text:
            return await event.reply(f"فرمت: `{PREFIX}hash sha256 متن` (یا Reply)")
        algos = [event.pattern_match.group(1)] if event.pattern_match.group(1) else list(H.ALGOS)
        await event.reply("\n".join(f"{a}: `{H.hash_text(a, text)}`" for a in algos))

    @client.on(cmd(r"b64\s+(enc|dec)(?:\s+(.+))?", "(?s)"))
    async def b64_cmd(event):
        text = await arg_or_reply(event, event.pattern_match.group(2))
        if not text:
            return await event.reply(f"فرمت: `{PREFIX}b64 enc|dec متن`")
        try:
            await event.reply(f"`{H.b64(event.pattern_match.group(1), text)}`")
        except ValueError as exc:
            await event.reply(f"❌ {exc}")

    # ------------------------------------------------------------------ 12. word count
    @client.on(cmd(r"wc(?:\s+(.+))?", "(?s)"))
    async def wc(event):
        text = await arg_or_reply(event, event.pattern_match.group(1))
        if not text:
            return await event.reply(f"روی یک متن Reply کن یا `{PREFIX}wc متن` بنویس.")
        s = H.text_stats(text)
        await event.reply(f"🔢 کلمه: {s['words']} | حرف: {s['chars']} (بدون فاصله {s['chars_nospace']}) | خط: {s['lines']}\n📖 زمان مطالعه ≈ {max(1, int(s['read_s']))} ثانیه")

    # ------------------------------------------------------------------ 13. pomodoro
    @client.on(cmd(r"pomo(?:\s+(stop|\d+))?(?:\s+(\d+))?"))
    async def pomo(event):
        a, b = event.pattern_match.group(1), event.pattern_match.group(2)
        if a == "stop":
            t = state["pomo"]
            if t:
                t.cancel()  # type: ignore[union-attr]
                state["pomo"] = None
            return await event.reply("⏹ پومودورو متوقف شد.")
        work = min(max(int(a), 1), 180) if a else 25
        rest = min(max(int(b), 1), 60) if b else 5
        if state["pomo"] and not state["pomo"].done():  # type: ignore[union-attr]
            return await event.reply(f"ℹ️ یک پومودورو در حال اجراست؛ `{PREFIX}pomo stop`")

        async def run():
            rounds = 0
            while True:
                await asyncio.sleep(work * 60)
                rounds += 1
                await client.send_message("me", f"🍅 دور {rounds}: {work} دقیقه کار تمام شد؛ {rest} دقیقه استراحت!")
                await asyncio.sleep(rest * 60)
                await client.send_message("me", "🍅 استراحت تمام شد؛ برگرد سر کار 💪")

        state["pomo"] = asyncio.get_running_loop().create_task(run())
        await event.reply(f"🍅 شروع شد: {work} دقیقه کار / {rest} دقیقه استراحت (نوتیف در Saved Messages)")

    # ------------------------------------------------------------------ 14. quotes
    @client.on(cmd(r"quote(?:\s+(add|list|del))?(?:\s+(.+))?", "(?s)"))
    async def quote(event):
        word, rest = event.pattern_match.group(1), (event.pattern_match.group(2) or "").strip()
        if word == "add":
            author = None
            text = rest
            if not text and event.is_reply:
                m = await event.get_reply_message()
                text = (getattr(m, "message", "") or "").strip() if m else ""
                try:
                    s = await m.get_sender()
                    author = " ".join(x for x in (getattr(s, "first_name", None), getattr(s, "last_name", None)) if x) or getattr(s, "title", None)
                except Exception:  # noqa: BLE001
                    author = None
            if not text:
                return await event.reply(f"روی یک پیام Reply کن یا `{PREFIX}quote add متن`")
            qid = await db.insert("INSERT INTO plus_quotes(text,author,ts) VALUES(?,?,?)", (text[:1500], author, time.time()))
            return await event.reply(f"💬 نقل‌قول #{qid} ذخیره شد.")
        if word == "del":
            n = await db.execute("DELETE FROM plus_quotes WHERE id=?", (int(rest),)) if rest.isdigit() else 0
            return await event.reply("🗑 حذف شد." if n else "❌ پیدا نشد.")
        if word == "list":
            rows = await db.fetchall("SELECT id,text FROM plus_quotes ORDER BY id DESC LIMIT 15")
            return await event.reply("💬 " + ("\n".join(f"#{r['id']} {r['text'][:60]}" for r in rows) or "خالی"))
        rows = await db.fetchall("SELECT text,author FROM plus_quotes")
        if not rows:
            return await event.reply(f"💬 چیزی ذخیره نشده؛ `{PREFIX}quote add` را روی یک پیام بزن.")
        r = random.choice(rows)
        await event.edit(f"💬 {r['text']}" + (f"\n— {r['author']}" if r["author"] else ""))

    # ------------------------------------------------------------------ 15. unread
    @client.on(cmd(r"unread(?:\s+(\d+))?"))
    async def unread(event):
        limit = min(int(event.pattern_match.group(1) or 10), 30)
        rows = []
        async for d in client.iter_dialogs(limit=150):
            if d.unread_count:
                rows.append((d.unread_count, d.name or "?"))
        rows.sort(reverse=True)
        if not rows:
            return await event.reply("📭 همه‌چیز خوانده شده.")
        total = sum(c for c, _ in rows)
        await event.reply(f"📬 {len(rows)} چت، {total} پیام خوانده‌نشده\n" + "\n".join(f"• {n}: {c}" for c, n in rows[:limit]))
