"""Helpers for `.dl` (YouTube / Instagram / TikTok). Pure functions, no network, easy to test.

Only these sites are accepted. That is also a safety rule: a link to an internal address or any other host never reaches yt-dlp.
"""
from __future__ import annotations

import re
from pathlib import Path
from typing import Any
from urllib.parse import urlparse

PLATFORMS: dict[str, tuple[str, ...]] = {
    "youtube": ("youtube.com", "youtu.be", "youtube-nocookie.com"),
    "instagram": ("instagram.com", "instagr.am"),
    "tiktok": ("tiktok.com",),
}
NAMES = {"youtube": "YouTube", "instagram": "Instagram", "tiktok": "TikTok"}
URL_RE = re.compile(r"https?://[^\s<>\"'«»]+", re.I)
HEIGHTS = (144, 240, 360, 480, 720, 1080, 1440, 2160)
VIDEO_EXT = {".mp4", ".mkv", ".webm", ".mov", ".m4v"}
IMAGE_EXT = {".jpg", ".jpeg", ".png", ".webp"}
AUDIO_EXT = {".mp3", ".m4a", ".opus", ".ogg", ".aac", ".wav"}
SKIP_EXT = {".part", ".ytdl", ".json", ".txt", ".description", ".vtt", ".srt", ".temp"}


def extract_url(text: str) -> str | None:
    m = URL_RE.search(text or "")
    if not m:
        return None
    return m.group(0).rstrip(".,;:!?)»”’'\"")


def platform_of(url: str) -> str | None:
    try:
        host = (urlparse(url).hostname or "").lower()
        scheme = urlparse(url).scheme.lower()
    except ValueError:
        return None
    if scheme not in {"http", "https"} or not host:
        return None
    for name, domains in PLATFORMS.items():
        if any(host == d or host.endswith("." + d) for d in domains):
            return name
    return None


def parse_args(raw: str) -> dict[str, Any]:
    """Parse options in any order. An omitted output mode is eligible for the interactive picker."""
    url = extract_url(raw)
    rest = URL_RE.sub(" ", raw or "")
    opts: dict[str, Any] = {
        "url": url, "audio": False, "height": 720, "me": False, "info": False, "best": False,
        "mode_explicit": False, "quality_explicit": False,
    }
    for tok in rest.lower().split():
        tok = tok.strip("،,؛;")
        if tok in {"audio", "mp3", "music", "صوت", "آهنگ", "اهنگ", "ویس", "voice", "sound"}:
            opts["audio"], opts["mode_explicit"] = True, True
        elif tok in {"mp4", "video", "film", "فیلم", "ویدیو", "ویدئو"}:
            opts["audio"], opts["mode_explicit"] = False, True
        elif tok in {"me", "saved", "من", "سیو", "ذخیره"}:
            opts["me"] = True
        elif tok in {"info", "اطلاعات", "مشخصات"}:
            opts["info"] = True
        elif tok in {"best", "max", "hd", "بهترین", "اچ‌دی"}:
            opts["best"], opts["height"], opts["quality_explicit"] = True, 1080, True
        elif tok == "4k":
            opts["height"], opts["quality_explicit"] = 2160, True
        elif tok == "2k":
            opts["height"], opts["quality_explicit"] = 1440, True
        else:
            m = re.fullmatch(r"(\d{3,4})p?", tok)
            if m and int(m.group(1)) in HEIGHTS:
                opts["height"], opts["quality_explicit"] = int(m.group(1)), True
    return opts


def format_selector(height: int, audio: bool) -> str:
    if audio:
        return "bestaudio[ext=m4a]/bestaudio/best"
    h = int(height)
    return (f"bv*[height<={h}][ext=mp4]+ba[ext=m4a]/bv*[height<={h}]+ba/"
            f"b[height<={h}][ext=mp4]/b[height<={h}]/best[height<={h}]/best")


def build_opts(workdir: str, *, audio: bool, height: int, max_mb: int, cookies: str = "", proxy: str = "", progress_hook: Any = None,
               have_ffmpeg: bool = True) -> dict[str, Any]:
    opts: dict[str, Any] = {
        "outtmpl": str(Path(workdir) / "%(id).60s.%(ext)s"),
        "format": format_selector(height, audio) if have_ffmpeg else (f"b[height<={int(height)}][ext=mp4]/b[ext=mp4]/best" if not audio else "bestaudio/best"),
        "noplaylist": True,
        "playlistend": 10,
        "quiet": True,
        "no_warnings": True,
        "noprogress": True,
        "socket_timeout": 20,
        "retries": 3,
        "fragment_retries": 3,
        "max_filesize": int(max_mb) * 1024 * 1024,
        "restrictfilenames": True,
        "nocheckcertificate": False,
        "consoletitle": False,
        "overwrites": True,
    }
    if have_ffmpeg and not audio:
        opts["merge_output_format"] = "mp4"
    if audio and have_ffmpeg:
        opts["postprocessors"] = [{"key": "FFmpegExtractAudio", "preferredcodec": "mp3", "preferredquality": "192"}]
    if cookies and Path(cookies).is_file():
        opts["cookiefile"] = cookies
    if proxy:
        opts["proxy"] = proxy
    if progress_hook is not None:
        opts["progress_hooks"] = [progress_hook]
    return opts


def collect_files(workdir: str) -> list[Path]:
    """Downloaded media in the work dir, oldest first, without temp/side files."""
    files = [p for p in Path(workdir).iterdir() if p.is_file() and p.suffix.lower() not in SKIP_EXT and not p.name.endswith(".part")]
    return sorted(files, key=lambda p: (p.stat().st_mtime, p.name))


def kind_of(path: Path) -> str:
    ext = path.suffix.lower()
    if ext in VIDEO_EXT:
        return "video"
    if ext in IMAGE_EXT:
        return "image"
    if ext in AUDIO_EXT:
        return "audio"
    return "file"


def human_size(n: float) -> str:
    for unit in ("B", "KB", "MB", "GB"):
        if n < 1024 or unit == "GB":
            return f"{n:.0f} {unit}" if unit == "B" else f"{n:.1f} {unit}"
        n /= 1024
    return f"{n:.1f} GB"


def human_duration(sec: float | int | None) -> str:
    s = int(sec or 0)
    h, rem = divmod(s, 3600)
    m, s = divmod(rem, 60)
    return f"{h}:{m:02d}:{s:02d}" if h else f"{m}:{s:02d}"


def impersonation_ok() -> bool:
    """Can yt-dlp really impersonate a browser (TLS fingerprint)? TikTok needs it.

    It comes from the optional `curl_cffi` package, and only counts when yt-dlp itself accepts that build
    (an installed but incompatible curl_cffi is just as useless as a missing one). If the check cannot run, assume OK.
    """
    try:
        from yt_dlp import YoutubeDL  # noqa: PLC0415
        from yt_dlp.networking.impersonate import ImpersonateTarget  # noqa: PLC0415
    except Exception:  # noqa: BLE001
        try:
            import curl_cffi  # noqa: F401, PLC0415
        except Exception:  # noqa: BLE001
            return False
        return True
    try:
        with YoutubeDL({"quiet": True, "no_warnings": True}) as ydl:
            return bool(ydl._impersonate_target_available(ImpersonateTarget()))  # noqa: SLF001
    except Exception:  # noqa: BLE001
        return True


def friendly_error(message: str, platform: str | None = None) -> str:
    """yt-dlp error text -> a short Persian explanation with the real fix."""
    m = (message or "").lower()
    if platform == "tiktok" and any(k in m for k in ("unexpected response from webpage", "unable to extract challenge", "unable to solve js challenge", "unable to extract universal data", "unable to extract webpage", "unable to extract sigi state")):
        if not impersonation_ok():
            return ("تیک‌تاک درخواست رو رد کرد چون yt-dlp نمی‌تونه خودش رو «مرورگر» نشون بده: بستهٔ `curl_cffi` نصب نیست (یا با این نسخه سازگار نیست).\n"
                    "روی سرور بزن: `pip install -U \"yt-dlp[default,curl-cffi]\"` و ربات رو ری‌استارت کن. با `.dl status` چک کن.")
        return ("تیک‌تاک این درخواست رو قبول نکرد (مرورگرنمایی فعاله، پس بیشتر شبیه بلاک شدن IP سروره).\n"
                "راه‌حل: `YTDLP_PROXY` (پراکسی/IP خونگی یا غیر دیتاسنتر) یا `YTDLP_COOKIES` (کوکی تیک‌تاک) توی `.env` بذار. "
                "همچنین `pip install -U yt-dlp` رو امتحان کن؛ تیک‌تاک مرتب سیستم ضدربات رو عوض می‌کنه.")
    if "larger than max-filesize" in m or "file is larger" in m:
        return "حجم فایل از سقف مجاز بیشتره (DL_MAX_MB). کیفیت پایین‌تر بده: `.dl 360 لینک` یا `.dl audio لینک`."
    if "sign in to confirm" in m or "not a bot" in m:
        return "یوتیوب سرور رو «ربات» فرض کرده. کوکی یوتیوب لازمه: فایل cookies.txt بساز و مسیرش رو در `.env` بذار (YTDLP_COOKIES=...)."
    if any(k in m for k in ("login required", "rate-limit reached", "private", "log in", "requires authentication", "empty media response", "not available")) \
            and platform == "instagram":
        return "اینستاگرام این پست رو بدون ورود نمی‌ده (پرایویت/محدودیت). برای پست‌های محدود، کوکی اینستاگرام لازمه (YTDLP_COOKIES در `.env`)."
    if "private video" in m or "is private" in m:
        return "این ویدیو خصوصیه."
    if "age" in m and ("restricted" in m or "confirm your age" in m):
        return "ویدیو محدودیت سنی داره؛ بدون کوکی حساب قابل دانلود نیست (YTDLP_COOKIES)."
    if "unavailable" in m or "removed" in m or "does not exist" in m or "404" in m:
        return "این لینک دیگه وجود نداره یا حذف شده."
    if "geo" in m or "not made this video available in your country" in m:
        return "این ویدیو برای کشور سرور بلوکه است (YTDLP_PROXY می‌تونه کمک کنه)."
    if "429" in m or "too many requests" in m:
        return "سایت موقتاً محدود کرده (Too Many Requests). چند دقیقه دیگه دوباره امتحان کن."
    if "unsupported url" in m:
        return "این نوع لینک پشتیبانی نمی‌شه (فقط پست/ویدیو/ریلز/شورت مستقیم)."
    if "live" in m and "event" in m:
        return "لایو یا ویدیوی هنوز-شروع‌نشده قابل دانلود نیست."
    first = (message or "").strip().splitlines()[0] if (message or "").strip() else "نامشخص"
    return "دانلود نشد: " + re.sub(r"\x1b\[[0-9;]*m", "", first)[:160] + "\n(اگه همین‌طور ادامه داشت `pip install -U yt-dlp` بزن؛ سایت‌ها زود‌به‌زود تغییر می‌کنن.)"
