"""Render a Telegram-like message bubble ("phone screenshot" look) as a WebP sticker.

Persian / Arabic text is shaped through, in this order:
  1. Pillow's RAQM layout engine (when libraqm + fribidi are present),
  2. `arabic_reshaper` + `python-bidi` (pure Python; listed in requirements.txt),
  3. plain drawing (letters unjoined) - never crashes.

Fonts: `assets/fonts/` ships Vazirmatn (OFL) - Persian letters AND Persian/Latin digits look right; DejaVu Sans is the
fallback. Emoji are drawn as colour pictures from `assets/emoji/` (Twemoji, CC-BY 4.0), also inside names and quotes.
A message that is only 1-3 emoji is drawn BIG, like Telegram's "jumbo" emoji.
"""
from __future__ import annotations

import io
import re
import unicodedata
from functools import lru_cache
from pathlib import Path
from typing import Iterable

from PIL import Image, ImageDraw, ImageFont, features

FONT_DIR = Path(__file__).resolve().parents[1] / "assets" / "fonts"
_PREFERRED = ("Vazirmatn", "Vazir", "IRANSans", "Sahel", "Shabnam", "Samim", "NotoNaskhArabic", "NotoSansArabic", "DejaVuSans")
_SYSTEM_DIRS = ("/usr/share/fonts", "/usr/local/share/fonts", str(Path.home() / ".fonts"))

_RTL = re.compile(r"[\u0590-\u08FF\uFB1D-\uFDFF\uFE70-\uFEFF]")
EMOJI_DIR = Path(__file__).resolve().parents[1] / "assets" / "emoji"
_PICT = (r"(?:[\U0001F000-\U0001FAFF\u2600-\u27BF\u2300-\u23FF\u2B00-\u2BFF\u2190-\u21FF\u2900-\u297F"
         r"\u00A9\u00AE\u203C\u2049\u2122\u2139\u24C2\u25AA-\u25FE\u3030\u303D\u3297\u3299])")
_MOD = r"[\U0001F3FB-\U0001F3FF]"
# keycap | flag | tag-flag (England...) | pictograph [VS16] [skin tone] (ZWJ pictograph ...)*
EMOJI_RE = re.compile(
    r"[0-9#*]\uFE0F?\u20E3"
    r"|[\U0001F1E6-\U0001F1FF]{2}"
    r"|\U0001F3F4[\U000E0020-\U000E007F]+"
    rf"|{_PICT}\uFE0F?{_MOD}?(?:\u200D{_PICT}\uFE0F?{_MOD}?)*", re.UNICODE)
_STRAY = re.compile("[\uFE0F\u200D\U000E0000-\U000E007F]")  # leftovers of unrenderable emoji
_PLACEHOLDERS = [chr(c) for c in range(0x2500, 0x2580) if not unicodedata.mirrored(chr(c))]  # bidi class ON, never mirrored

try:  # optional shaping helpers
    import arabic_reshaper as _reshaper  # type: ignore
except Exception:  # noqa: BLE001
    _reshaper = None
try:
    from bidi.algorithm import get_display as _get_display  # type: ignore
except Exception:  # noqa: BLE001
    try:
        from bidi import get_display as _get_display  # type: ignore
    except Exception:  # noqa: BLE001
        _get_display = None

HAS_RAQM = bool(features.check("raqm")) and bool(features.check("fribidi")) and bool(features.check("harfbuzz"))

PALETTE = (  # Telegram's name colours
    (224, 85, 85), (230, 126, 34), (155, 89, 182), (39, 174, 96), (22, 160, 160), (52, 152, 219), (233, 30, 99))

THEMES = {
    "dark": {"bg": (24, 37, 51), "bubble": (43, 82, 120), "text": (255, 255, 255), "time": (170, 200, 230), "chat": (14, 22, 33)},
    "light": {"bg": (231, 235, 240), "bubble": (255, 255, 255), "text": (20, 20, 20), "time": (130, 140, 150), "chat": (222, 229, 236)},
}


def has_rtl(text: str) -> bool:
    return bool(_RTL.search(text or ""))


def strip_unrenderable(text: str) -> str:
    """Drop control / format characters. Emoji are KEPT (they are drawn as pictures by `draw_rich`)."""
    text = (text or "").replace("\u200f", "").replace("\u200e", "").replace("\u202a", "").replace("\u202b", "").replace("\u202c", "")
    return "".join(ch for ch in text if ch in "\n\t\uFE0F\u200D" or unicodedata.category(ch)[0] != "C" or 0xE0020 <= ord(ch) <= 0xE007F)


def is_emoji(cluster: str) -> bool:
    return bool(EMOJI_RE.fullmatch(cluster))


def only_emoji(text: str) -> list[str] | None:
    """['😀', '❤️'] when the text is nothing but 1-3 emoji (Telegram draws those jumbo), else None."""
    body = re.sub(r"\s+", "", text or "")
    if not body:
        return None
    found = EMOJI_RE.findall(body)
    if not found or "".join(found) != body or len(found) > 3:
        return None
    return found


def find_font(bold: bool = False) -> str | None:
    wanted = "bold" if bold else "regular"
    candidates: list[Path] = []
    for base in [FONT_DIR, *[Path(d) for d in _SYSTEM_DIRS if Path(d).exists()]]:
        try:
            candidates.extend(p for p in base.rglob("*") if p.suffix.lower() in {".ttf", ".otf"})
        except OSError:
            continue
    def score(p: Path) -> tuple[int, int]:
        name = p.name.lower()
        is_bold = "bold" in name or "black" in name
        for i, pref in enumerate(_PREFERRED):
            if name.startswith(pref.lower()):
                if "oblique" in name or "italic" in name or "mono" in name or "serif" in name or "condensed" in name or "light" in name:
                    return (99, i)
                return (i if is_bold == (wanted == "bold") else i + 50, 0 if str(p).startswith(str(FONT_DIR)) else 1)
        return (999, 0)
    ranked = sorted((score(p), str(p)) for p in candidates)
    return ranked[0][1] if ranked and ranked[0][0][0] < 99 else None


def load_font(size: int, bold: bool = False) -> ImageFont.FreeTypeFont | ImageFont.ImageFont:
    path = find_font(bold)
    if path:
        try:
            if HAS_RAQM:
                return ImageFont.truetype(path, size, layout_engine=ImageFont.Layout.RAQM)
            return ImageFont.truetype(path, size)
        except Exception:  # noqa: BLE001
            try:
                return ImageFont.truetype(path, size)
            except Exception:  # noqa: BLE001
                pass
    return ImageFont.load_default()


_BASIC: dict[tuple[str, int], ImageFont.FreeTypeFont] = {}


def basic_font(font):
    """Same face/size WITHOUT the RAQM engine (for text that was already shaped + reordered by us)."""
    path, size = getattr(font, "path", None), getattr(font, "size", None)
    if not path or not size:
        return font
    key = (str(path), int(size))
    if key not in _BASIC:
        try:
            _BASIC[key] = ImageFont.truetype(str(path), int(size))
        except Exception:  # noqa: BLE001
            return font
    return _BASIC[key]


def shape(text: str) -> str:
    """Return text ready to be drawn left-to-right by Pillow (only used without RAQM)."""
    if HAS_RAQM or not has_rtl(text):
        return text
    out = text
    if _reshaper is not None:
        try:
            out = _reshaper.reshape(out)
        except Exception:  # noqa: BLE001
            pass
    if _get_display is not None:
        try:
            out = _get_display(out)
        except Exception:  # noqa: BLE001
            pass
    return out


def _draw_kwargs(text: str) -> dict:
    if HAS_RAQM and has_rtl(text):
        return {"direction": "rtl", "language": "fa"}
    return {}


@lru_cache(maxsize=2048)
def _emoji_path(cluster: str) -> str | None:
    cps = [ord(c) for c in cluster]
    no_vs = [c for c in cps if c != 0xFE0F]
    variants = [cps if 0x200D in cps else no_vs, cps, no_vs]
    base = [c for c in no_vs if not 0x1F3FB <= c <= 0x1F3FF]  # drop skin tone
    variants += [base, base[:1]]
    for v in variants:
        if not v:
            continue
        f = EMOJI_DIR / ("-".join(f"{c:x}" for c in v) + ".png")
        if f.exists():
            return str(f)
    return None


@lru_cache(maxsize=512)
def emoji_image(cluster: str, px: int) -> Image.Image | None:
    path = _emoji_path(cluster)
    if not path:
        return None
    try:
        return Image.open(path).convert("RGBA").resize((px, px), Image.Resampling.LANCZOS)
    except Exception:  # noqa: BLE001
        return None


def _emoji_px(font) -> int:
    return max(8, int(round(getattr(font, "size", 24) * 1.15)))


def visual_runs(text: str) -> list[tuple[str, str]]:
    """[('t', 'text') | ('e', '😀'), ...] in the order they are DRAWN left to right (bidi + Arabic joining already applied)."""
    found = list(EMOJI_RE.finditer(text))
    if not found:
        return [("t", shape(text))]
    pool = [c for c in _PLACEHOLDERS if c not in text]
    mapping: dict[str, str] = {}
    out, last = [], 0
    for m in found:
        if len(mapping) >= len(pool):
            out.append(text[last:m.end()])  # absurd amount of emoji in one line: keep the rest as it is
            last = m.end()
            continue
        out.append(text[last:m.start()])
        ph = pool[len(mapping)]
        mapping[ph] = m.group(0)
        out.append(ph)
        last = m.end()
    out.append(text[last:])
    logical = "".join(out)
    visual = logical
    if has_rtl(logical):
        if _reshaper is not None:
            try:
                visual = _reshaper.reshape(visual)
            except Exception:  # noqa: BLE001
                pass
        if _get_display is not None:
            try:
                visual = _get_display(visual)
            except Exception:  # noqa: BLE001
                pass
    runs: list[tuple[str, str]] = []
    buf = ""
    for ch in visual:
        if ch in mapping:
            if buf:
                runs.append(("t", buf))
                buf = ""
            runs.append(("e", mapping[ch]))
        else:
            buf += ch
    if buf:
        runs.append(("t", _STRAY.sub("", buf)))
    return runs


def rich_width(font, text: str, *, emoji_px: int | None = None) -> float:
    """Width of `text` as drawn by `draw_rich` (emoji = pictures)."""
    if not EMOJI_RE.search(text or ""):
        return text_width(font, text)
    px = emoji_px or _emoji_px(font)
    bf = basic_font(font)
    total = 0.0
    for kind, val in visual_runs(text):
        if kind == "e":
            total += px + 2 if emoji_image(val, px) is not None else 0
        elif val:
            total += bf.getlength(val)
    return total


def draw_rich(canvas: Image.Image, xy: tuple[float, float], text: str, font, fill, *, right: bool = False,
              emoji_px: int | None = None) -> None:
    """Draw one line. `xy` = left edge (or right edge when right=True) and the TOP of the line."""
    x, y = xy
    d = ImageDraw.Draw(canvas)
    if not EMOJI_RE.search(text or ""):
        d.text((x, y), shape(text), font=font, fill=fill, anchor="ra" if right else "la", **_draw_kwargs(text))
        return
    px = emoji_px or _emoji_px(font)
    size = getattr(font, "size", 24)
    bf = basic_font(font)
    x0 = x - rich_width(font, text, emoji_px=px) if right else x
    for kind, val in visual_runs(text):
        if kind == "e":
            img = emoji_image(val, px)
            if img is None:
                continue
            canvas.paste(img, (int(round(x0)), int(round(y + (size * 1.2 - px) / 2 + size * 0.08))), img)
            x0 += px + 2
        elif val:
            d.text((x0, y), val, font=bf, fill=fill, anchor="la")
            x0 += bf.getlength(val)


def text_width(font, text: str) -> float:
    return font.getlength(shape(text), **_draw_kwargs(text)) if not isinstance(font, ImageFont.ImageFont) or hasattr(font, "getlength") else len(text) * 6


def _clusters(word: str) -> list[str]:
    """Split a word into drawable units (an emoji cluster is one unit)."""
    out, last = [], 0
    for m in EMOJI_RE.finditer(word):
        out.extend(word[last:m.start()])
        out.append(m.group(0))
        last = m.end()
    out.extend(word[last:])
    return out


def wrap(text: str, font, max_width: int) -> list[str]:
    """Greedy word wrap preserving explicit newlines. Works in logical order; shaping is applied per line."""
    lines: list[str] = []
    for para in (text or "").split("\n"):
        words = para.split(" ")
        cur = ""
        for w in words:
            trial = (cur + " " + w).strip() if cur else w
            if rich_width(font, trial) <= max_width or not cur:
                cur = trial
                # single very long token: hard split (never inside an emoji)
                while rich_width(font, cur) > max_width and len(_clusters(cur)) > 1:
                    units = _clusters(cur)
                    cut = len(units)
                    while cut > 1 and rich_width(font, "".join(units[:cut])) > max_width:
                        cut -= 1
                    lines.append("".join(units[:cut]))
                    cur = "".join(units[cut:])
            else:
                lines.append(cur)
                cur = w
        lines.append(cur)
    return lines or [""]


def circle_avatar(data: bytes | None, size: int, name: str, color: tuple[int, int, int]) -> Image.Image:
    img = None
    if data:
        try:
            img = Image.open(io.BytesIO(data)).convert("RGBA")
            side = min(img.size)
            left, top = (img.width - side) // 2, (img.height - side) // 2
            img = img.crop((left, top, left + side, top + side)).resize((size, size), Image.Resampling.LANCZOS)
        except Exception:  # noqa: BLE001
            img = None
    if img is None:
        img = Image.new("RGBA", (size, size), color + (255,))
        d = ImageDraw.Draw(img)
        first = (_clusters(name.strip()) or ["?"])[0]
        pic = emoji_image(first, int(size * 0.56)) if is_emoji(first) else None
        if pic is not None:
            img.paste(pic, ((size - pic.width) // 2, (size - pic.height) // 2), pic)
        else:
            initial = first.upper() if not is_emoji(first) else "?"
            f = load_font(int(size * 0.5), bold=True)
            d.text((size / 2, size / 2), shape(initial), font=f, fill=(255, 255, 255, 255), anchor="mm")
    mask = Image.new("L", (size * 4, size * 4), 0)
    ImageDraw.Draw(mask).ellipse((0, 0, size * 4 - 1, size * 4 - 1), fill=255)
    mask = mask.resize((size, size), Image.Resampling.LANCZOS)
    img.putalpha(mask)
    return img


def render_message_sticker(*, name: str, text: str, avatar: bytes | None = None, time_text: str = "", theme: str = "dark",
                           user_id: int = 0, reply_name: str | None = None, reply_text: str | None = None,
                           media_label: str | None = None, photo: bytes | None = None) -> bytes:
    """Return WebP bytes (max side 512) that look like a screenshot of one Telegram message."""
    th = THEMES.get(theme, THEMES["dark"])
    color = PALETTE[abs(int(user_id)) % len(PALETTE)]
    name = strip_unrenderable(name).strip() or "?"
    body = strip_unrenderable(text).strip()
    if not body and media_label:
        body = media_label
    jumbo = only_emoji(body) if not photo else None
    scale = 2  # draw big, shrink at the end for crisp edges
    f_text, f_name, f_small = load_font(26 * scale // 2 * 1, False), load_font(24 * scale // 2, True), load_font(18 * scale // 2)
    pad, av = 18 * scale // 2, 52 * scale // 2
    max_text_w = 430 * scale // 2
    rtl = has_rtl(body) or (not body and has_rtl(name))

    if jumbo:  # Telegram draws 1-3 emoji big and without text
        jpx = {1: 112, 2: 92, 3: 78}[len(jumbo)]
        lines = ["".join(jumbo)]
        line_h = jpx + 8
        widths = [len(jumbo) * (jpx + 8) - 8]
    else:
        lines = wrap(body[:900], f_text, max_text_w)[:18]
        if len(body) > 900 or len(lines) == 18:
            lines[-1] = lines[-1][: max(0, len(lines[-1]) - 1)] + "…"
        line_h = int(getattr(f_text, "size", 26) * 1.35)
        widths = [rich_width(f_text, ln) for ln in lines]
    name_w = rich_width(f_name, name)
    time_w = text_width(f_small, time_text) if time_text else 0
    quote_h = 0
    quote_lines: list[str] = []
    if reply_text:
        quote_lines = wrap(strip_unrenderable(reply_text)[:140], f_small, max_text_w - 20)[:2]
        quote_h = (len(quote_lines) + 1) * int(getattr(f_small, "size", 18) * 1.3) + 10
        widths.append(max([rich_width(f_small, q) for q in quote_lines] + [rich_width(f_name, reply_name or "")]) + 20)

    photo_img = None
    photo_h = 0
    if photo:
        try:
            photo_img = Image.open(io.BytesIO(photo)).convert("RGB")
            ratio = max_text_w / photo_img.width
            photo_img = photo_img.resize((max_text_w, max(40, min(int(photo_img.height * ratio), 380 * scale // 2))), Image.Resampling.LANCZOS)
            photo_h = photo_img.height + 8
            widths.append(photo_img.width)
        except Exception:  # noqa: BLE001
            photo_img = None

    content_w = int(max([name_w, *widths, time_w + 10, 120]))
    bubble_w = content_w + pad * 2
    bubble_h = pad + int(getattr(f_name, "size", 24) * 1.4) + quote_h + photo_h + line_h * len(lines) + int(getattr(f_small, "size", 18) * 1.4) + pad // 2
    margin = 14 * scale // 2
    tail = 10 * scale // 2
    W = margin * 2 + av + 10 + bubble_w
    H = margin * 2 + max(bubble_h, av)
    canvas = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    d = ImageDraw.Draw(canvas)

    bx0, by0 = margin + av + 10, margin
    d.rounded_rectangle((bx0, by0, bx0 + bubble_w, by0 + bubble_h), radius=22 * scale // 2, fill=th["bubble"] + (255,))
    d.polygon([(bx0 + 2, by0 + bubble_h - 30), (bx0 - tail, by0 + bubble_h), (bx0 + 24, by0 + bubble_h - 2)], fill=th["bubble"] + (255,))

    canvas.alpha_composite(circle_avatar(avatar, av, name, color), (margin, by0 + bubble_h - av if bubble_h > av else by0))

    x_left, x_right = bx0 + pad, bx0 + bubble_w - pad
    y = by0 + pad // 2 + 2
    draw_rich(canvas, (x_right if has_rtl(name) else x_left, y), name, f_name, color + (255,), right=has_rtl(name))
    y += int(getattr(f_name, "size", 24) * 1.4)

    if quote_lines:
        d.rounded_rectangle((x_left, y, x_left + 5, y + quote_h - 8), radius=3, fill=color + (255,))
        qy = y
        if reply_name:
            draw_rich(canvas, (x_left + 14, qy), strip_unrenderable(reply_name), f_name, color + (255,))
            qy += int(getattr(f_small, "size", 18) * 1.3)
        for q in quote_lines:
            draw_rich(canvas, (x_left + 14, qy), q, f_small, th["time"] + (255,))
            qy += int(getattr(f_small, "size", 18) * 1.3)
        y += quote_h

    if photo_img is not None:
        m = Image.new("L", photo_img.size, 0)
        ImageDraw.Draw(m).rounded_rectangle((0, 0, photo_img.width - 1, photo_img.height - 1), radius=14, fill=255)
        canvas.paste(photo_img, (x_left, y), m)
        y += photo_h

    if jumbo:
        total = widths[0]
        x0 = x_right - total if rtl else x_left
        for cluster in jumbo:
            pic = emoji_image(cluster, jpx)
            if pic is not None:
                canvas.paste(pic, (int(x0), int(y + 4)), pic)
            x0 += jpx + 8
        y += line_h
    else:
        for ln in lines:
            right = has_rtl(ln) or (rtl and not ln.strip())
            draw_rich(canvas, (x_right if right else x_left, y), ln, f_text, th["text"] + (255,), right=right)
            y += line_h
    if time_text:
        d.text((x_right if not rtl else x_left, by0 + bubble_h - pad // 2 - 2), time_text, font=f_small, fill=th["time"] + (255,), anchor="rb" if not rtl else "lb")

    # Telegram stickers: one side must be exactly 512 px, the other <= 512
    scale_f = 512 / max(canvas.size)
    canvas = canvas.resize((max(1, round(canvas.width * scale_f)), max(1, round(canvas.height * scale_f))), Image.Resampling.LANCZOS)
    out = io.BytesIO()
    canvas.save(out, "WEBP", lossless=True, quality=90, method=4)
    return out.getvalue()
