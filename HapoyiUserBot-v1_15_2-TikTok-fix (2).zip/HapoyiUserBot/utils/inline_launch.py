"""Post an inline-bot result into ANY chat on behalf of the user account (the bot need not be a member)."""
from __future__ import annotations

from typing import Any


async def post_inline(client: Any, bot: Any, query: str, chat_id: Any, reply_to: int | None = None) -> None:
    """userbot -> inline query to the Assistant Bot -> click the first result into `chat_id`.

    Needs inline mode enabled for the bot in @BotFather (/setinline). Raises on any failure so the caller
    can fall back to `bot.send_message` (which needs the bot to be in the chat).
    """
    username = (await bot.get_me()).username
    results = await client.inline_query(username, query)
    if not results:
        raise RuntimeError("inline query returned no results (is inline mode enabled in @BotFather?)")
    await results[0].click(chat_id, reply_to=reply_to)
